--
-- PostgreSQL database dump
--

\restrict qyChl5smWfuyHAfbUvjGhsfyX0WE5lNN5yNA3C7ZGNwY4AlVcjBNoloxg1vp0eZ

-- Dumped from database version 17.8 (a48d9ca)
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ZENK; Type: SCHEMA; Schema: -; Owner: neondb_owner
--

CREATE SCHEMA "ZENK";


ALTER SCHEMA "ZENK" OWNER TO neondb_owner;

--
-- Name: audit; Type: SCHEMA; Schema: -; Owner: neondb_owner
--

CREATE SCHEMA audit;


ALTER SCHEMA audit OWNER TO neondb_owner;

--
-- Name: neon_auth; Type: SCHEMA; Schema: -; Owner: neon_auth
--

CREATE SCHEMA neon_auth;


ALTER SCHEMA neon_auth OWNER TO neon_auth;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: channel_type_enum; Type: TYPE; Schema: ZENK; Owner: neondb_owner
--

CREATE TYPE "ZENK".channel_type_enum AS ENUM (
    'persistent',
    'stage'
);


ALTER TYPE "ZENK".channel_type_enum OWNER TO neondb_owner;

--
-- Name: kyc_status_enum; Type: TYPE; Schema: ZENK; Owner: neondb_owner
--

CREATE TYPE "ZENK".kyc_status_enum AS ENUM (
    'pending',
    'approved',
    'rejected'
);


ALTER TYPE "ZENK".kyc_status_enum OWNER TO neondb_owner;

--
-- Name: persona_enum; Type: TYPE; Schema: ZENK; Owner: neondb_owner
--

CREATE TYPE "ZENK".persona_enum AS ENUM (
    'sponsor',
    'vendor',
    'student'
);


ALTER TYPE "ZENK".persona_enum OWNER TO neondb_owner;

--
-- Name: log_chat_ban_activity(); Type: FUNCTION; Schema: ZENK; Owner: neondb_owner
--

CREATE FUNCTION "ZENK".log_chat_ban_activity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        DECLARE
            admin_id_val TEXT;
        BEGIN
            admin_id_val := current_setting('zenk.current_admin_id', true);
            
            IF admin_id_val IS NULL OR admin_id_val = '' THEN
                admin_id_val := '00000000-0000-0000-0000-000000000000'; -- System/Unknown
            END IF;

            IF (TG_OP = 'INSERT') THEN
                INSERT INTO audit.admin_access_log (id, admin_id, action, target_table, target_id, changes_json, created_at)
                VALUES (uuid_generate_v4()::text, admin_id_val, 'CREATE_BAN', 'chat_bans', NEW.id::text, 
                        jsonb_build_object('circle_id', NEW.circle_id, 'user_id', NEW.user_id, 'reason', NEW.reason), 
                        now());
                RETURN NEW;
            ELSIF (TG_OP = 'DELETE') THEN
                INSERT INTO audit.admin_access_log (id, admin_id, action, target_table, target_id, changes_json, created_at)
                VALUES (uuid_generate_v4()::text, admin_id_val, 'REVOKE_BAN', 'chat_bans', OLD.id::text, 
                        jsonb_build_object('circle_id', OLD.circle_id, 'user_id', OLD.user_id), 
                        now());
                RETURN OLD;
            END IF;
            RETURN NULL;
        END;
        $$;


ALTER FUNCTION "ZENK".log_chat_ban_activity() OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chat_bans; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".chat_bans (
    id uuid NOT NULL,
    circle_id uuid NOT NULL,
    user_id uuid NOT NULL,
    banned_by_admin_id uuid,
    reason text NOT NULL,
    reported_message_content text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".chat_bans OWNER TO neondb_owner;

--
-- Name: chat_channels; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".chat_channels (
    id uuid NOT NULL,
    circle_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    channel_type "ZENK".channel_type_enum NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".chat_channels OWNER TO neondb_owner;

--
-- Name: chat_messages; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".chat_messages (
    id uuid NOT NULL,
    channel_id uuid NOT NULL,
    gamified_persona_id uuid NOT NULL,
    content_text text,
    media_url character varying(1000),
    shield_action character varying(20) NOT NULL,
    shield_reason character varying(100),
    is_edited boolean NOT NULL,
    hidden_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".chat_messages OWNER TO neondb_owner;

--
-- Name: circle_members; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".circle_members (
    id uuid NOT NULL,
    circle_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role character varying(50) NOT NULL,
    joined_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".circle_members OWNER TO neondb_owner;

--
-- Name: enrollments; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".enrollments (
    id uuid NOT NULL,
    circle_id uuid NOT NULL,
    user_id uuid NOT NULL,
    enrolled_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE "ZENK".enrollments OWNER TO neondb_owner;

--
-- Name: gamified_personas; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".gamified_personas (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    nickname character varying(100) NOT NULL,
    avatar_key character varying(100) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".gamified_personas OWNER TO neondb_owner;

--
-- Name: kyc_documents; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".kyc_documents (
    id uuid NOT NULL,
    signup_id uuid NOT NULL,
    original_filename character varying(512) NOT NULL,
    stored_filename character varying(512) NOT NULL,
    stored_path text NOT NULL,
    content_type character varying(128),
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".kyc_documents OWNER TO neondb_owner;

--
-- Name: notifications; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".notifications (
    id uuid NOT NULL,
    recipient_id character varying(255) NOT NULL,
    recipient_type character varying(50) NOT NULL,
    notification_type character varying(50) NOT NULL,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    related_entity_id character varying(255),
    related_entity_type character varying(50),
    is_read boolean NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".notifications OWNER TO neondb_owner;

--
-- Name: parental_consent_log; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".parental_consent_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    student_id uuid NOT NULL,
    consent_type character varying(100) NOT NULL,
    verified_by_admin_id uuid NOT NULL,
    verified_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE "ZENK".parental_consent_log OWNER TO neondb_owner;

--
-- Name: signup_requests; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".signup_requests (
    id uuid NOT NULL,
    persona "ZENK".persona_enum NOT NULL,
    full_name character varying(200) NOT NULL,
    mobile character varying(32) NOT NULL,
    email character varying(320) NOT NULL,
    password_hash character varying(255) NOT NULL,
    address_line1 character varying(300) NOT NULL,
    address_line2 character varying(300) NOT NULL,
    city character varying(120) NOT NULL,
    state character varying(120) NOT NULL,
    pincode character varying(20) NOT NULL,
    country character varying(120) NOT NULL,
    sponsor_type character varying(50),
    pan_number character varying(32),
    company_name character varying(200),
    company_registration_number character varying(64),
    gst_number character varying(32),
    authorized_signatory_name character varying(200),
    authorized_signatory_designation character varying(120),
    business_name character varying(200),
    business_type character varying(50),
    product_categories text,
    website character varying(300),
    date_of_birth date,
    school_or_college_name character varying(250),
    grade_or_year character varying(50),
    guardian_name character varying(200),
    guardian_mobile character varying(32),
    kyc_status "ZENK".kyc_status_enum NOT NULL,
    admin_note text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".signup_requests OWNER TO neondb_owner;

--
-- Name: sos_reports; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".sos_reports (
    id uuid NOT NULL,
    message_id uuid NOT NULL,
    reporter_persona_id uuid NOT NULL,
    hidden_at timestamp with time zone,
    admin_notified_at timestamp with time zone,
    resolved_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".sos_reports OWNER TO neondb_owner;

--
-- Name: sponsor_circles; Type: TABLE; Schema: ZENK; Owner: neondb_owner
--

CREATE TABLE "ZENK".sponsor_circles (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE "ZENK".sponsor_circles OWNER TO neondb_owner;

--
-- Name: admin_access_log; Type: TABLE; Schema: audit; Owner: neondb_owner
--

CREATE TABLE audit.admin_access_log (
    id character varying(36) NOT NULL,
    admin_id character varying(36) NOT NULL,
    action character varying(100) NOT NULL,
    target_table character varying(100) NOT NULL,
    target_id character varying(36) NOT NULL,
    changes_json jsonb,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE audit.admin_access_log OWNER TO neondb_owner;

--
-- Name: account; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.account (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "accountId" text NOT NULL,
    "providerId" text NOT NULL,
    "userId" uuid NOT NULL,
    "accessToken" text,
    "refreshToken" text,
    "idToken" text,
    "accessTokenExpiresAt" timestamp with time zone,
    "refreshTokenExpiresAt" timestamp with time zone,
    scope text,
    password text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE neon_auth.account OWNER TO neon_auth;

--
-- Name: invitation; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.invitation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "organizationId" uuid NOT NULL,
    email text NOT NULL,
    role text,
    status text NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "inviterId" uuid NOT NULL
);


ALTER TABLE neon_auth.invitation OWNER TO neon_auth;

--
-- Name: jwks; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.jwks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "publicKey" text NOT NULL,
    "privateKey" text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "expiresAt" timestamp with time zone
);


ALTER TABLE neon_auth.jwks OWNER TO neon_auth;

--
-- Name: member; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.member (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "organizationId" uuid NOT NULL,
    "userId" uuid NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL
);


ALTER TABLE neon_auth.member OWNER TO neon_auth;

--
-- Name: organization; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.organization (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    logo text,
    "createdAt" timestamp with time zone NOT NULL,
    metadata text
);


ALTER TABLE neon_auth.organization OWNER TO neon_auth;

--
-- Name: project_config; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.project_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    endpoint_id text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    trusted_origins jsonb NOT NULL,
    social_providers jsonb NOT NULL,
    email_provider jsonb,
    email_and_password jsonb,
    allow_localhost boolean NOT NULL,
    plugin_configs jsonb,
    webhook_config jsonb
);


ALTER TABLE neon_auth.project_config OWNER TO neon_auth;

--
-- Name: session; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "userId" uuid NOT NULL,
    "impersonatedBy" text,
    "activeOrganizationId" text
);


ALTER TABLE neon_auth.session OWNER TO neon_auth;

--
-- Name: user; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth."user" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "emailVerified" boolean NOT NULL,
    image text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    role text,
    banned boolean,
    "banReason" text,
    "banExpires" timestamp with time zone
);


ALTER TABLE neon_auth."user" OWNER TO neon_auth;

--
-- Name: verification; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.verification (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE neon_auth.verification OWNER TO neon_auth;

--
-- Data for Name: chat_bans; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".chat_bans (id, circle_id, user_id, banned_by_admin_id, reason, reported_message_content, created_at) FROM stdin;
d8dc6842-99ac-43e9-9db1-a84dac53c681	481eba8f-778d-4618-8f9e-6e6b263d89a0	96bbf32a-eef0-43e4-9526-220295705dbf	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	Policy violation found in report	hello	2026-03-23 16:37:58.076141+00
\.


--
-- Data for Name: chat_channels; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".chat_channels (id, circle_id, name, channel_type, created_at) FROM stdin;
c98727c2-30b6-4c6b-9af0-6c55506414ec	481eba8f-778d-4618-8f9e-6e6b263d89a0	general	persistent	2026-03-19 16:22:40.645374+00
2259092e-46c6-4869-8b2d-70c4d88dc9bf	481eba8f-778d-4618-8f9e-6e6b263d89a0	announcements	persistent	2026-03-24 17:04:49.448721+00
0485b420-a989-4aaf-bdc5-935d4976d087	481eba8f-778d-4618-8f9e-6e6b263d89a0	mentorship-qa	persistent	2026-03-24 17:04:49.453246+00
c6c66d5d-fc5c-4318-9360-4d5a926a2523	481eba8f-778d-4618-8f9e-6e6b263d89a0	resources	persistent	2026-03-24 17:04:49.454261+00
6d9674df-e1b6-4a40-afed-e9b8327d9829	481eba8f-778d-4618-8f9e-6e6b263d89a0	milestones	persistent	2026-03-24 17:04:49.455243+00
13db44f3-e119-47e3-b00b-21dc5c8f3073	481eba8f-778d-4618-8f9e-6e6b263d89a0	opportunities	persistent	2026-03-24 17:04:49.456243+00
19c66119-896c-49b2-ad6a-7d8188fbcd3d	481eba8f-778d-4618-8f9e-6e6b263d89a0	introductions	persistent	2026-03-24 17:04:49.457737+00
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".chat_messages (id, channel_id, gamified_persona_id, content_text, media_url, shield_action, shield_reason, is_edited, hidden_at, deleted_at, created_at) FROM stdin;
71b7f841-d511-42a3-9d64-e64bbc8c981c	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	\N	/chat/uploads/af03399f1dcf4f1baf7f267289dab2d1.png	allow	\N	f	\N	\N	2026-03-19 16:47:52.852695+00
f2e2a21a-3649-4e49-a08f-cbf061ecce16	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	lets chat on whatsapp	\N	allow	\N	f	\N	\N	2026-03-19 16:49:04.772707+00
8c4d6ba8-d8ce-4ed9-b21b-731cb75b0d54	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	My phone number is 900315171	\N	warn	off_platform_intent	f	\N	\N	2026-03-19 16:49:29.751477+00
155152bf-860d-4d6b-a4ab-31cf8dff52e7	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	hi	\N	allow	\N	f	\N	\N	2026-03-19 16:51:28.136636+00
8ba9deb3-805b-46ac-bc23-f9b9f878a678	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	how are you	\N	allow	\N	f	\N	\N	2026-03-19 16:51:31.723471+00
4f9d1efb-a942-4d78-85c8-4c0787972e9b	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	lsut	\N	warn	identity_signal	f	\N	\N	2026-03-19 16:51:38.005363+00
cf4b25e1-ee23-41b0-aa68-8bb599eee8a9	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	insta id is 123	\N	allow	\N	f	\N	\N	2026-03-19 16:51:46.716235+00
fb3ec8b7-5f43-4a2e-b3de-ddc967f4bd04	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	hi there	\N	allow	\N	f	\N	\N	2026-03-19 16:53:35.942131+00
ce2d5050-3d90-467a-95d1-8f3386e1542a	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	how are you	\N	allow	\N	f	\N	\N	2026-03-19 16:55:11.939844+00
1cc6d845-8a75-4f34-9fe4-02e1c00fc5c8	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	hi	\N	allow	\N	f	\N	\N	2026-03-19 17:11:12.42403+00
66f367b5-e2d2-4d89-b1cf-a684a987fb23	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	hi	\N	allow	\N	f	\N	\N	2026-03-19 17:16:24.793439+00
49d153a8-3e75-4f1e-a317-f531585d1af2	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	hi	\N	allow	\N	f	\N	\N	2026-03-19 17:28:47.061528+00
07b80ef2-3c28-4684-9a05-cb7478a15665	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	how are you	\N	allow	\N	f	\N	\N	2026-03-19 17:28:52.966484+00
6ec48d7c-8ece-4790-9d25-7dc535af68da	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	i hope everone is fine	\N	allow	\N	f	\N	\N	2026-03-19 17:29:06.093629+00
81aa4e68-4270-4f54-bd23-67d89111af0e	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	how is everone?	\N	allow	\N	f	\N	\N	2026-03-19 17:30:13.70294+00
c9c6511f-d359-4ec1-a188-a26870615562	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	how are you	\N	allow	\N	f	\N	\N	2026-03-19 17:37:46.368249+00
28850a25-4c09-4b0e-8657-bc3b16e10a8e	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	lets connect on instagram	\N	warn	off_platform_intent	f	\N	\N	2026-03-19 17:37:55.976731+00
80bb4e83-243f-42ab-8b82-56e7a82796fa	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	hi	\N	allow	\N	f	\N	\N	2026-03-19 17:38:57.184081+00
88b07a72-298e-4686-a4b6-be16d4a16b76	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	this is student4	\N	allow	\N	f	\N	\N	2026-03-19 18:06:38.266374+00
d1c95870-b921-4ebf-abf7-89904c846c01	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	hi	\N	allow	\N	f	\N	2026-03-19 18:15:52.753157+00	2026-03-19 18:15:49.964147+00
50a5f829-7c5c-479f-980d-b9855c65c074	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	hi	\N	allow	\N	f	2026-03-19 18:24:23.520087+00	\N	2026-03-19 17:37:38.941574+00
5e778a38-f8c4-4d16-b7da-30388889c562	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	hello	\N	allow	\N	f	2026-03-19 18:26:34.501412+00	\N	2026-03-19 17:39:05.255274+00
1ae40fca-a203-474f-bc68-7395f9fbbfda	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	test	\N	allow	\N	f	2026-03-19 18:31:30.980099+00	\N	2026-03-19 17:59:16.441501+00
03972879-c030-4fd9-ad13-de6bc3170054	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	lets connect on isnta	\N	allow	\N	f	2026-03-19 18:38:16.762311+00	\N	2026-03-19 18:07:08.909946+00
7d598a87-a58c-4ba0-8e0a-69e9398900e6	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	this is user 23	\N	allow	\N	f	\N	2026-03-19 18:38:41.188856+00	2026-03-19 17:52:04.413932+00
e11a0c2a-6698-4e5c-a5bc-5170c3cb117e	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	this is test user 4	\N	allow	\N	f	2026-03-19 18:39:09.978973+00	\N	2026-03-19 17:47:33.328659+00
05920eab-7fd1-44b8-9c00-ee803194c1b8	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	hi there this is user 1 from circle 1	\N	allow	\N	f	\N	\N	2026-03-19 19:51:04.82908+00
03879bc8-e407-4d28-857f-e6743507bce2	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	this is user 2 from circle 1	\N	allow	\N	f	\N	2026-03-19 19:51:51.310998+00	2026-03-19 19:51:47.303253+00
9a691be5-fb32-450e-8f35-08a6828e5549	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	user2 from circle 2	\N	allow	\N	f	2026-03-19 19:52:09.299336+00	\N	2026-03-19 19:51:58.475857+00
089585fa-9ccc-41e3-8f35-54ae432d5564	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	he is my ig	\N	allow	\N	f	\N	2026-03-19 19:59:13.973388+00	2026-03-19 19:59:04.118706+00
cebeff68-2bfe-4f5e-8c65-208ae44c7b24	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	whatsapp me	\N	warn	off_platform_intent	f	2026-03-19 19:59:47.195997+00	\N	2026-03-19 19:59:37.489351+00
9738040d-fecf-484a-bd86-b50f6a2391d8	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	here is my number 1234565	\N	allow	\N	f	2026-03-19 20:48:24.185244+00	\N	2026-03-19 19:54:17.865772+00
4f66a223-93f3-4d03-bcfa-2cf6b249e9ed	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	lets connect on ig	\N	allow	\N	f	2026-03-19 20:57:35.878896+00	\N	2026-03-19 18:07:02.666465+00
e1f4a04e-95f0-4492-acbe-26e5cf4ab2c2	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	lets conmnect on instagram	\N	warn	off_platform_intent	f	2026-03-19 21:02:01.399601+00	\N	2026-03-19 19:54:44.734445+00
3ce65e24-a597-4d5a-b343-1b9faefa1801	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	this is ujser 3 in circle 1	\N	allow	\N	f	2026-03-19 21:04:05.02162+00	\N	2026-03-19 19:53:21.02446+00
4a8b327f-81d6-40bf-bdde-b68650870ad7	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	\N	/chat/uploads/91d7a21dd60343efa60ae1b81354c15b.png	allow	\N	f	2026-03-19 21:09:43.565062+00	\N	2026-03-19 17:38:10.269985+00
2879fe6f-402c-4b78-805d-d41122c44342	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	\N	/chat/uploads/2b268bdd8de54a9385ccfa716cb6ccfa.png	allow	\N	f	2026-03-19 21:17:38.230525+00	\N	2026-03-19 17:12:43.58016+00
1fc49983-19c9-4559-8691-5aacb0d407e4	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	i hope all good	\N	allow	\N	f	2026-03-19 21:23:25.674692+00	\N	2026-03-19 17:11:24.324765+00
8030cf4e-9ed3-4ccb-bce8-e97269a784a5	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	kill your self	\N	allow	\N	f	2026-03-23 15:51:32.671628+00	\N	2026-03-19 16:48:57.971052+00
8e463f25-819a-4ba0-b198-12eb0131cb15	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	sd	\N	allow	\N	f	2026-03-23 16:11:38.676176+00	\N	2026-03-19 17:12:52.331441+00
5ae6fd5c-670c-471e-9752-d2e358d0a84d	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	lets connect on instagram	\N	warn	off_platform_intent	f	\N	2026-03-23 16:13:34.42514+00	2026-03-19 17:29:11.887877+00
a79772e7-38ab-4284-b6ff-28a31f9a7488	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	hello	\N	allow	\N	f	2026-03-23 16:13:36.92552+00	\N	2026-03-19 16:47:44.640835+00
e1ae6836-d801-4bfc-a970-e1a49a9fb66a	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	lets connect on instagram	\N	warn	off_platform_intent	f	2026-03-23 16:23:08.322946+00	\N	2026-03-19 19:54:58.870657+00
86f7a197-e036-438b-8b47-b10cb4800bf3	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	todays session on eng	\N	allow	\N	f	2026-03-23 16:37:21.567262+00	\N	2026-03-19 20:00:56.998186+00
52b45e9c-2c08-4f2b-8028-039a9c918a96	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	hello	\N	allow	\N	f	2026-03-23 16:37:54.711408+00	\N	2026-03-19 16:55:08.134099+00
0b274955-917f-49f3-a257-60e6a18a00b6	c98727c2-30b6-4c6b-9af0-6c55506414ec	100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	how are you	\N	allow	\N	f	2026-03-24 04:50:34.89942+00	\N	2026-03-19 17:11:19.929309+00
484dbcb5-534d-4366-823c-42de3cbe456d	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	this user 2	\N	allow	\N	f	\N	\N	2026-03-24 05:29:00.513613+00
c4c68868-cde4-468a-a9db-14db6106f50a	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	this is  correct user 2	\N	allow	\N	f	\N	\N	2026-03-24 05:29:12.072532+00
e8a89a82-48ec-4ff3-aa44-93a0bd293338	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	lets connect on whatsapp	\N	allow	\N	f	\N	\N	2026-03-24 05:29:19.215126+00
61425d33-e5ee-4555-aadc-4518d70e784e	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	hi'	\N	allow	\N	f	2026-03-24 17:00:19.387956+00	\N	2026-03-19 21:23:07.874041+00
53708eac-3d03-46cf-bb4f-3545fabe61b9	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	lets connect on instagram	\N	warn	off_platform_intent	f	2026-03-24 05:30:06.74701+00	\N	2026-03-24 05:29:26.921783+00
213e2cdf-159b-469f-97af-3a915c53d8d8	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	lets connect on whatsapp	\N	allow	\N	f	\N	2026-03-24 16:54:49.053646+00	2026-03-24 16:54:41.037348+00
72f55746-f629-430c-9a1a-8428c01b9182	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	lets connect on instagram	\N	warn	off_platform_intent	f	\N	\N	2026-03-24 16:57:03.014704+00
bf0f3000-a4de-41e3-9546-f6ff8d7fcd04	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	this is test user 4	\N	allow	\N	f	\N	\N	2026-03-24 17:06:18.945742+00
f9c539bc-46a0-4df0-8731-ea198ddee068	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	instagrm	\N	allow	\N	f	\N	2026-03-24 17:40:40.513787+00	2026-03-24 17:40:27.857824+00
02563bfc-249f-4499-b9be-4320c9ee5aa2	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	instagram	\N	allow	\N	f	\N	\N	2026-03-24 17:40:41.841673+00
9dcabddc-507c-4167-89ba-158f517c3ad8	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	good morning😀	\N	allow	\N	f	\N	\N	2026-03-25 05:00:25.887728+00
cfee72f2-2e6a-4b59-897a-8548f328ab4e	2259092e-46c6-4869-8b2d-70c4d88dc9bf	74067a42-7a31-4094-936b-3a703429a972	hello	\N	allow	\N	f	\N	\N	2026-03-25 05:00:33.030685+00
15c5b837-89fc-48b9-99c2-f933903cc4ca	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	🙃	\N	allow	\N	f	\N	\N	2026-03-25 05:21:09.241422+00
e7e3078f-09b7-449a-88e8-a3c87ef2b4fe	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	fsv	\N	allow	\N	f	\N	\N	2026-03-25 06:01:49.911086+00
3107ffdc-5c9b-4754-a96a-d3fb8f9974c5	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	instagram	\N	allow	\N	f	\N	2026-03-25 06:02:29.03601+00	2026-03-25 06:02:24.746552+00
a116879e-4e8a-4b54-98b4-64f91c2de9e8	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	this is user*	\N	allow	\N	f	\N	\N	2026-03-25 13:14:58.362855+00
b082b050-b1ca-4024-a9f5-44f615912cd2	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	lets connect on insagram	\N	allow	\N	f	2026-03-25 13:15:11.829453+00	\N	2026-03-24 16:56:44.007078+00
3309346c-befa-4e04-a822-a93380fb43d8	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	user 1 here	\N	allow	\N	f	\N	\N	2026-03-25 13:18:20.783077+00
1971d873-5955-4961-aab7-e3fb6f12ee96	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	killyourdselg	\N	allow	\N	f	\N	2026-03-25 13:22:24.187216+00	2026-03-25 13:22:20.171545+00
e1c1773a-86d6-474b-9ec6-62c555d2cf75	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	kill yourslef	\N	allow	\N	f	\N	2026-03-25 13:23:44.934364+00	2026-03-25 13:23:25.953152+00
462faff8-1ae4-4525-b33b-b2537d7ceebf	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	testuser!	\N	allow	\N	f	\N	\N	2026-03-25 13:28:50.097238+00
f9d0eaaf-83ce-4514-b563-1ce35aad61e4	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	this is user 2	\N	allow	\N	f	\N	\N	2026-03-25 15:28:52.812084+00
783b0b98-a69b-486d-84ef-39e2b35b08fc	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	lets connect on instagram	\N	warn	off_platform_intent	f	2026-03-25 15:52:15.501543+00	\N	2026-03-25 06:02:38.047973+00
e531baef-834c-466f-acee-97ed7d04e0ec	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	lets connect on instagram	\N	warn	off_platform_intent	f	\N	\N	2026-03-25 15:52:55.182053+00
3d0df4cf-d569-4d72-b00b-7130e65bab9f	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	lets connect on whatsapp	\N	warn	off_platform_intent	f	\N	\N	2026-03-29 13:49:38.982465+00
56f0b5f8-32a0-4574-bb23-c64088b86b0c	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	lets discuss about vietnam war	\N	warn	identity_signal	f	\N	\N	2026-03-29 13:49:50.609074+00
26148d56-18b6-42c2-b6ea-99c44509a3ac	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	how are you	\N	allow	\N	f	\N	\N	2026-03-29 13:49:54.396584+00
0200d98e-e255-44d3-815a-1b7239c9a440	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	what do you think about israel	\N	warn	identity_signal	f	\N	\N	2026-03-29 13:50:13.263374+00
4db3e218-7335-48a0-8c33-b065220ead15	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	lets start a session on englishg	\N	allow	\N	f	\N	\N	2026-03-29 13:50:29.072306+00
0f29da9c-5f5f-4e17-a53b-8a204137da83	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	what do you think about irasel	\N	allow	\N	f	\N	\N	2026-03-29 13:50:47.100122+00
60b80faa-d68f-4545-9d9a-adc075b4cc27	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	israel	\N	warn	identity_signal	f	\N	\N	2026-03-29 13:50:53.202699+00
f901e3fb-421e-451c-8362-8ba3883a569d	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	should india attack pakistan	\N	warn	identity_signal	f	\N	\N	2026-03-29 13:51:04.641999+00
55f00e78-f9ae-484e-befb-58f8cd73eb4b	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	vietnam	\N	warn	identity_signal	f	\N	\N	2026-03-29 13:51:19.634521+00
d9433fef-3931-413d-82f9-7c1352215e8a	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	hi there	\N	allow	\N	f	\N	\N	2026-03-29 13:52:20.846407+00
7acc26e5-896f-4ed1-93ae-8d6cb47da8ae	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	you bastard	\N	allow	\N	f	\N	2026-03-29 14:31:32.561402+00	2026-03-29 13:52:50.013674+00
b0f7cfca-34c1-474f-b4ac-576d59e848c6	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	india support palesine	\N	warn	identity_signal	f	\N	2026-03-29 14:31:52.275717+00	2026-03-29 14:31:42.720801+00
7a7113d2-6b77-4ded-aa2b-476aa2479f82	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	delhi is capital of india	\N	allow	\N	f	\N	\N	2026-03-29 14:38:37.857812+00
738884a1-01ee-4e0e-9f3d-3de24cf152af	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	delhi will attack karachi	\N	allow	\N	f	\N	2026-03-29 14:39:31.952412+00	2026-03-29 14:39:25.761281+00
75cf7994-072a-412a-aa8f-561622e47e35	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	whom do you support iran is israel	\N	allow	\N	f	\N	\N	2026-03-29 15:12:18.932264+00
79b910bb-ff49-4c80-abf0-91a82b542e72	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	should france attack on china	\N	allow	\N	f	\N	\N	2026-03-29 15:25:01.168562+00
9231fdff-7bc7-4bbf-a1b0-56d9696d13b8	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	should france attack on china	\N	allow	\N	f	\N	\N	2026-03-29 15:51:12.611941+00
574d2cc1-0c78-4f5f-b4f8-22a77b798b6b	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	should france attack on china	\N	allow	\N	f	\N	\N	2026-03-29 15:51:22.863995+00
a2efbe53-7aad-4289-810c-453dd7d425d6	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	should france attack on china	\N	allow	\N	f	\N	\N	2026-03-29 15:55:16.446511+00
66f1715c-9fc1-45b3-a9f2-422b9c623ceb	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	delhi is capital of india	\N	allow	\N	f	\N	\N	2026-03-29 15:56:34.751954+00
b81f83ec-5a74-4781-a150-1df227d1dcce	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	delhi should fire on karachi	\N	allow	\N	f	\N	2026-03-29 15:56:53.111922+00	2026-03-29 15:56:44.986342+00
8efc8d40-ef97-4c36-8ea1-20be3e434ba6	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	ig id 123	\N	allow	\N	f	\N	2026-03-29 15:57:45.702875+00	2026-03-29 15:57:40.892773+00
6a62f370-ac59-4297-859b-12ab8848e9dd	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	hindi is language of india	\N	allow	\N	f	\N	2026-03-30 07:55:34.08504+00	2026-03-30 07:55:29.875639+00
0de11465-de85-4329-a60e-c191216f8835	2259092e-46c6-4869-8b2d-70c4d88dc9bf	3566731e-6660-4385-bd6f-8aef9903eb59	delhi is cpital of india	\N	allow	\N	f	\N	2026-03-30 08:03:11.752711+00	2026-03-30 08:02:46.791339+00
ddf41072-8fce-4d11-b064-16d6ca45ec1d	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	this is user 4	\N	allow	\N	f	\N	\N	2026-03-30 08:04:50.613353+00
3c3df9b0-b403-4463-bb2c-449e04327b61	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	lets discuss about membership	\N	allow	\N	f	\N	\N	2026-03-30 08:05:01.149038+00
b96094d3-a082-482a-808f-99ced1b2b351	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	you want to go for drinks tommorow	\N	allow	\N	f	\N	\N	2026-03-30 16:39:06.962451+00
1ef2a822-59ce-45e7-9dfd-e7852aa9f2c3	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	tehran is capital of iran	\N	allow	\N	f	2026-03-30 16:42:54.043142+00	\N	2026-03-30 07:55:15.907499+00
59199b07-eca1-4aed-a1dc-8aac696bc668	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	hi	\N	allow	\N	f	\N	\N	2026-03-31 07:45:00.654633+00
db5ceff1-1f4d-44ba-915a-178cee6dd9bd	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	how are you guys	\N	allow	\N	f	\N	\N	2026-03-31 07:45:10.280334+00
d534fbc5-34ec-483c-92ff-591b1dbed37d	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	😴😴😴😴	\N	allow	\N	f	\N	\N	2026-03-31 07:55:04.868827+00
00f31ec2-1082-4284-ac21-85d0bbe00fa1	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	how are you	\N	allow	\N	f	\N	\N	2026-03-31 11:36:00.374456+00
bfbfb274-6b48-49b4-96f2-d004d27b3f8b	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	I need help with my physics homework	\N	allow	\N	f	\N	\N	2026-03-31 11:52:14.482516+00
cb3d9a44-9839-404a-872c-fad4b9437a15	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	I need help with my physics homework	\N	allow	\N	f	\N	\N	2026-03-31 11:55:35.239975+00
0f237c4d-a9f2-484d-9652-03f846e03dc6	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	Kia, can you give me some guidance on physics?	\N	allow	\N	f	\N	\N	2026-03-31 11:55:56.966467+00
c6c04b53-95ad-461e-8057-a931f344c221	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	Kia suggests: this is a test of the suggestion box styling.	\N	allow	\N	f	\N	\N	2026-03-31 11:58:16.66459+00
3ca73c90-53ae-407a-a5f1-606fb26e7654	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	kia help me with physics	\N	allow	\N	f	\N	\N	2026-03-31 11:59:52.529787+00
d85b1535-0ccc-4827-9ebd-cc12100f6dd6	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	Can you help me with a physics problem?	\N	allow	\N	f	\N	\N	2026-03-31 12:03:42.463979+00
11397001-a958-4320-98c3-574715657c3f	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	Kia, can you help me with a physics problem?	\N	allow	\N	f	\N	\N	2026-03-31 12:11:09.729737+00
fad3f1c3-27c8-44e3-ac08-39b092014634	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	this is user 5	\N	allow	\N	f	\N	\N	2026-04-03 11:27:44.373251+00
d7a38086-9ec3-4246-998b-058b8af51c71	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	lets connect	\N	allow	\N	f	\N	\N	2026-04-03 11:28:02.894543+00
08ef4a0f-42a5-4e8e-91d3-c0250782a305	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	hie	\N	allow	\N	f	\N	\N	2026-04-03 15:11:22.737732+00
096c14f4-d796-4a18-8818-1b8e36cbfa6b	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233516/zenk/chat/ajxapcndjwu9lyxx3t8m.png	allow	\N	f	\N	2026-03-19 19:52:46.792159+00	2026-03-19 19:52:38.957993+00
13af68db-24c8-4de8-82ad-a926f0329908	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233509/zenk/chat/i7cu0ugvjo5gcti242td.png	allow	\N	f	2026-03-19 18:21:46.955812+00	\N	2026-03-19 17:46:34.213278+00
2a771c96-c106-4c9e-852b-26b477d6b377	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233525/zenk/chat/pbhcumebvzxub9v1zjkk.png	allow	\N	f	\N	\N	2026-03-23 16:25:46.11865+00
379e8429-6f27-42c9-ae46-f7bce5d6bbe6	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233521/zenk/chat/kqc3mciixs7sl7jxod3q.png	allow	\N	f	2026-03-19 20:45:45.080625+00	\N	2026-03-19 18:41:33.404005+00
4238db1d-282d-4977-843d-fa123e2d823e	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233519/zenk/chat/k1t0zq1ayscd1lp2t8fv.png	allow	\N	f	\N	\N	2026-03-19 20:01:05.15264+00
43f7cc75-3dcb-4650-a0e8-2f2b0eea3955	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233528/zenk/chat/ielmuoganxg7j4tukqwz.png	allow	\N	f	2026-03-24 04:51:10.497876+00	\N	2026-03-23 16:25:51.614135+00
4d86221a-b6c5-45a7-8206-3de2c45d093a	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233514/zenk/chat/d30rkoun6wva5kid0k1q.png	allow	\N	f	2026-03-19 18:42:01.72508+00	\N	2026-03-19 18:41:36.427426+00
628efa6a-69e8-44ed-88e6-43a59b52e61d	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233545/zenk/chat/vlaltghur3o9wgg2ct1f.pdf	allow	\N	f	\N	2026-03-30 08:01:50.915056+00	2026-03-30 08:01:40.033369+00
6420b3af-a42d-49a8-852f-77235334529a	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233531/zenk/chat/dahohcpe6yqoblpcjuzi.png	allow	\N	f	\N	\N	2026-03-24 14:54:56.292649+00
651f0416-cba1-487e-8274-a7574b23091c	c98727c2-30b6-4c6b-9af0-6c55506414ec	74067a42-7a31-4094-936b-3a703429a972	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233513/zenk/chat/jfhomczxax3gnns8kwzf.png	allow	\N	f	2026-03-19 18:39:57.646988+00	\N	2026-03-19 18:38:12.7459+00
7b7fd710-acb0-4882-84a7-85b8a13ff04b	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233547/zenk/chat/pxfjoavpuzbrxpv0pmvv.jpg	allow	\N	f	2026-03-31 07:49:21.20272+00	\N	2026-03-30 08:07:56.161651+00
7ca509ec-9c23-4c33-8869-17af1e28e267	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233543/zenk/chat/inwbmsx8b0oxhguvdhok.png	allow	\N	f	\N	\N	2026-03-25 13:19:38.419038+00
85dbdb3b-0b42-405b-9b24-856acd1c8e63	c98727c2-30b6-4c6b-9af0-6c55506414ec	3566731e-6660-4385-bd6f-8aef9903eb59	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233554/zenk/chat/z0ldigztmxslnz4nirtm.jpg	allow	\N	f	\N	\N	2026-04-03 15:09:36.688062+00
a0800cd3-6ab6-4ee7-8e6c-8276b9a8d93d	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233511/zenk/chat/airraak9xkncteo172ux.png	allow	\N	f	2026-03-19 18:30:51.279036+00	\N	2026-03-19 17:46:50.406633+00
027d32ca-4d01-48b6-bc18-bf841572c6e6	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	😆😆😆😆	\N	allow	\N	f	\N	\N	2026-04-03 16:36:51.847472+00
d58a7a75-48fe-4bc5-8f4d-5c58069a6a06	c98727c2-30b6-4c6b-9af0-6c55506414ec	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	delhi is capital of india	\N	allow	\N	f	\N	\N	2026-04-03 17:22:38.119265+00
cf0f9a40-0944-450c-843e-e24fa26e6d61	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	have some alcohol	\N	allow	\N	f	\N	2026-04-03 17:34:20.502287+00	2026-04-03 17:31:26.970586+00
785ee2fb-a3c3-45ad-a0a6-897a014da6ed	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	dubai is awesome	\N	allow	\N	f	\N	\N	2026-04-03 17:34:29.830813+00
c04cd637-d98b-4235-a6e0-61fc3f0f6b0d	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	gulf is under attack	\N	allow	\N	f	\N	2026-04-03 17:35:46.695745+00	2026-04-03 17:34:53.965101+00
78ecebe4-d1f2-4185-8721-a9bd52f0f633	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	lets drink alcoholoo	\N	allow	\N	f	\N	2026-04-03 17:36:57.240896+00	2026-04-03 17:36:53.169105+00
8d481766-0c9a-4c35-b921-170995c85bf1	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	alcool based sanitizer	\N	allow	\N	f	\N	2026-04-03 17:38:10.254507+00	2026-04-03 17:36:34.261074+00
aaf8d237-5419-4d60-a4f8-f195c4b841fc	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	this is sender 3	\N	allow	\N	f	\N	\N	2026-04-03 17:38:15.966322+00
49e96d55-13c0-4d31-a53c-6a1b5726a7cc	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	i hope you are doing great	\N	allow	\N	f	\N	\N	2026-04-03 17:38:23.35086+00
bb9bcbc1-0bce-49a8-b9d7-8f23e1e10e11	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	have a nice day	\N	allow	\N	f	\N	\N	2026-04-03 17:38:29.036929+00
6a304656-71b4-4ceb-a41c-1e96429aeb8a	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	or just kill yourselfg	\N	allow	\N	f	\N	2026-04-03 17:40:39.921936+00	2026-04-03 17:38:33.691113+00
39280c34-668a-4448-8912-996d231b474e	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775238056/zenk/chat/i66l4jdip08lx3yd8xfa.png	allow	\N	f	\N	\N	2026-04-03 17:40:56.827214+00
df0d9980-5f69-4c3c-954c-f80e8292a214	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775238088/zenk/chat/k0hut6hqfylrz7wewg3i.png	allow	\N	f	\N	\N	2026-04-03 17:41:28.771972+00
f35ee7ce-821f-4a5c-8ef2-8cbce5754450	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775238133/zenk/chat/rwlpnt15eezzgotjerfk.jpg	allow	\N	f	\N	\N	2026-04-03 17:42:15.899234+00
5f7f29a1-d725-47e5-a0ee-c2fd21f4f804	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	fkkk off	\N	allow	\N	f	\N	2026-04-03 17:45:29.873895+00	2026-04-03 17:45:26.574245+00
2faba64f-6301-4cba-82f3-a75179f2fa32	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	should india defend iran	\N	allow	\N	f	\N	2026-04-03 17:45:34.885843+00	2026-04-03 17:42:34.661568+00
04d5a24f-e69e-42aa-aedd-c516b6e46c5a	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	lets discuss about geopolitics	\N	allow	\N	f	\N	2026-04-03 17:45:37.926397+00	2026-04-03 17:42:15.564574+00
f34dbb57-c6bf-437c-af77-74dfbc68f5bd	c98727c2-30b6-4c6b-9af0-6c55506414ec	81bfbce8-f290-4772-8ef2-c432eaa49a32	nig	\N	allow	\N	f	\N	2026-04-03 17:47:42.226451+00	2026-04-03 17:47:37.976546+00
855f0c73-f82c-4eb0-8e06-595c2164bdf6	19c66119-896c-49b2-ad6a-7d8188fbcd3d	c17ce59c-9328-41da-9df9-f545c92fa2e1	hi this is user 3	\N	allow	\N	f	\N	\N	2026-04-03 18:04:42.473782+00
3a062adb-74fa-4c56-a634-1048f4483edc	c98727c2-30b6-4c6b-9af0-6c55506414ec	c17ce59c-9328-41da-9df9-f545c92fa2e1	this is user b5	\N	allow	\N	f	\N	\N	2026-04-03 18:08:28.125433+00
f8ae0f95-8b9f-4988-b705-5ba39dfb1161	0485b420-a989-4aaf-bdc5-935d4976d087	81bfbce8-f290-4772-8ef2-c432eaa49a32	what is zenk	\N	allow	\N	f	\N	\N	2026-04-03 18:10:10.02697+00
a5884221-d51b-47b3-8272-2b6ecd940d42	c6c66d5d-fc5c-4318-9360-4d5a926a2523	81bfbce8-f290-4772-8ef2-c432eaa49a32	\N	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775239818/zenk/chat/okpmayis01adyakov9ye.jpg	allow	\N	f	\N	2026-04-03 18:10:28.412819+00	2026-04-03 18:10:18.962536+00
\.


--
-- Data for Name: circle_members; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".circle_members (id, circle_id, user_id, role, joined_at) FROM stdin;
91bcde50-d4b8-4be0-8d43-d9ba43c152ce	481eba8f-778d-4618-8f9e-6e6b263d89a0	96bbf32a-eef0-43e4-9526-220295705dbf	sponsor	2026-03-19 16:22:40.645374+00
8ead2910-85aa-43f0-821a-bddba4dc9ddb	481eba8f-778d-4618-8f9e-6e6b263d89a0	d0bf206f-61e6-4b94-8312-61c8809f3187	student	2026-03-19 17:06:39.716065+00
98a02b1f-d846-4a48-83c3-5582f299e2fa	481eba8f-778d-4618-8f9e-6e6b263d89a0	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	student	2026-03-19 17:25:56.706549+00
1765c6c4-c585-40f2-a56d-f7043890a427	481eba8f-778d-4618-8f9e-6e6b263d89a0	89c1ad50-a73e-4f02-8e61-1c14a37343ea	student	2026-03-19 17:25:56.914816+00
0aa3045e-c04c-4b01-9c5a-96ca19637625	481eba8f-778d-4618-8f9e-6e6b263d89a0	01c3110c-8b3f-44b9-96cf-c119f937dcdc	student	2026-03-19 17:25:57.11726+00
e9b4a0ef-7550-444b-ac25-6a63a77d170a	481eba8f-778d-4618-8f9e-6e6b263d89a0	0ddbc297-568f-41c8-9159-4424e517faf9	student	2026-03-19 17:25:57.320129+00
01871455-386e-41c7-adbd-b66e4781e539	481eba8f-778d-4618-8f9e-6e6b263d89a0	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	student	2026-03-19 17:25:57.522886+00
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".enrollments (id, circle_id, user_id, enrolled_at, is_active) FROM stdin;
8f21f6bc-6128-4dbd-ad64-70372fc7c3af	481eba8f-778d-4618-8f9e-6e6b263d89a0	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	2026-03-19 17:25:56.711065+00	t
97083757-ba82-4efb-b57a-9fd5946f0fc9	481eba8f-778d-4618-8f9e-6e6b263d89a0	89c1ad50-a73e-4f02-8e61-1c14a37343ea	2026-03-19 17:25:56.915821+00	t
b944cc7e-8932-48f6-99da-5f868ff4891c	481eba8f-778d-4618-8f9e-6e6b263d89a0	01c3110c-8b3f-44b9-96cf-c119f937dcdc	2026-03-19 17:25:57.118783+00	t
95085df9-e76e-4316-9177-7495997b895a	481eba8f-778d-4618-8f9e-6e6b263d89a0	0ddbc297-568f-41c8-9159-4424e517faf9	2026-03-19 17:25:57.321143+00	t
b1702097-ac9e-4734-b5e3-0db993664926	481eba8f-778d-4618-8f9e-6e6b263d89a0	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	2026-03-19 17:25:57.523848+00	t
\.


--
-- Data for Name: gamified_personas; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".gamified_personas (id, user_id, nickname, avatar_key, created_at) FROM stdin;
100316af-b0cb-4ce5-978b-bfbc9b0d3e4d	96bbf32a-eef0-43e4-9526-220295705dbf	harsh_6067	avatar_b39cecb2	2026-03-19 16:47:38.635709+00
e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	TestUser1	avatar1	2026-03-19 17:25:56.703377+00
74067a42-7a31-4094-936b-3a703429a972	89c1ad50-a73e-4f02-8e61-1c14a37343ea	TestUser2	avatar2	2026-03-19 17:25:56.913551+00
81bfbce8-f290-4772-8ef2-c432eaa49a32	01c3110c-8b3f-44b9-96cf-c119f937dcdc	TestUser3	avatar3	2026-03-19 17:25:57.11726+00
3566731e-6660-4385-bd6f-8aef9903eb59	0ddbc297-568f-41c8-9159-4424e517faf9	TestUser4	avatar4	2026-03-19 17:25:57.320129+00
c17ce59c-9328-41da-9df9-f545c92fa2e1	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	TestUser5	avatar5	2026-03-19 17:25:57.521821+00
\.


--
-- Data for Name: kyc_documents; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".kyc_documents (id, signup_id, original_filename, stored_filename, stored_path, content_type, created_at) FROM stdin;
6430a17e-074a-4e99-9b9a-daacf0597ebb	96bbf32a-eef0-43e4-9526-220295705dbf	232.png	96bbf32a-eef0-43e4-9526-220295705dbf_c8e2a92aa0dd46bfa78bc0611d18f11e_232.png	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233758/zenk/kyc/96bbf32a-eef0-43e4-9526-220295705dbf/ncyqnrumdz1jeps5ilmo.png	image/png	2026-03-19 10:47:15.651717+00
8c38558a-560d-4053-8e69-300f23919277	d0bf206f-61e6-4b94-8312-61c8809f3187	232.png	d0bf206f-61e6-4b94-8312-61c8809f3187_199fd4fcc5c94c66946c3a412562647c_232.png	https://res.cloudinary.com/dhlmxyh9f/image/upload/v1775233759/zenk/kyc/d0bf206f-61e6-4b94-8312-61c8809f3187/xus32jiudrutqqtcctqh.png	image/png	2026-03-19 11:05:15.177086+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".notifications (id, recipient_id, recipient_type, notification_type, title, message, related_entity_id, related_entity_type, is_read, read_at, created_at) FROM stdin;
50a1c67b-4c1f-4dfa-b8a5-aa25997838af	admin	admin	kyc_pending	New Sponsor Registration	harsh (harsh@gmail.com) has registered and is awaiting KYC approval.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:47:15.701523+00
e3a83626-62a8-47fe-ac06-5600a1695765	admin	admin	kyc_pending	New Sponsor Registration	harsh (harsh@gmail.com) has registered and is awaiting KYC approval.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:47:18.137969+00
e4d09281-1a4c-4bf0-846a-8a032a3839ae	admin	admin	kyc_pending	New Sponsor Registration	harsh (harsh@gmail.com) has registered and is awaiting KYC approval.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:08.954654+00
97a7fde9-3851-4828-84a3-49a82e24ef9d	admin	admin	kyc_pending	New Sponsor Registration	harsh (harsh@gmail.com) has registered and is awaiting KYC approval.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:12.04668+00
ba4c6155-4be2-4d71-8c70-f3168d30faeb	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:48.571418+00
0ab9a3b9-28d1-4b32-87cb-f3dff758866e	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:49.499313+00
c245c247-7447-4611-a7f5-106d2db5cee1	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:49.718196+00
76f85cbb-e567-4f7d-8803-b01fd032a0ed	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:49.917896+00
ebe7b697-ff7c-467e-bc79-8a8d5e33bd4d	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:50.111913+00
ca1e8f84-e94a-4a58-80a1-3ea09291abe0	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:50.30184+00
e8f85867-9fa4-412b-92eb-9a2f4ab2b53a	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:50.479383+00
5001bebf-4a47-4dfc-a479-2f5dcfa747da	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:50.668035+00
df38a628-b2e2-43cf-a498-856e3c2c78fa	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:53.804495+00
2ddaf019-66df-4a8b-a152-84b767d9cbdf	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:53.992116+00
47ac5b25-3721-4ba5-b6e7-e591eb56ac71	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:54.170287+00
e7515f0b-532a-440f-8543-bb037f13a4c1	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:54.340298+00
82d9d0f7-2878-4bda-9ccc-4e42dc180887	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:51:57.03876+00
47c51ec5-97fd-43d6-b3e1-499a8e9a8fa3	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:52:02.714551+00
626bfb2f-4741-4f08-bd58-82dbbec0aec1	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:52:03.172996+00
9809ad8f-be4b-4f49-b0e2-145a470b7ca1	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:52:03.36462+00
d3c4770c-883a-428f-ab15-16bfd5eeef03	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:52:03.539579+00
3fd83e96-34b2-4caf-9c92-1275a14c0a36	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 10:52:03.738653+00
30fce845-132e-4800-8f4b-94d428a139fb	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 11:00:34.645643+00
27f4ace4-43a7-46ef-8276-7ffb6c3e543b	96bbf32a-eef0-43e4-9526-220295705dbf	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	96bbf32a-eef0-43e4-9526-220295705dbf	signup	f	\N	2026-03-19 11:00:39.395112+00
83c1a9e7-e62e-464f-86cb-557ee058f4c4	admin	admin	kyc_pending	New Sponsor Registration	harsh (harsh1@gmail.com) has registered and is awaiting KYC approval.	d0bf206f-61e6-4b94-8312-61c8809f3187	signup	f	\N	2026-03-19 11:05:15.216268+00
ce170d28-c9f3-4f4e-be3c-703784d55913	d0bf206f-61e6-4b94-8312-61c8809f3187	user	kyc_approved	KYC Approved! 🎉	Congratulations harsh! Your sponsor registration has been approved. You can now access all features.	d0bf206f-61e6-4b94-8312-61c8809f3187	signup	f	\N	2026-03-19 11:23:13.364861+00
\.


--
-- Data for Name: parental_consent_log; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".parental_consent_log (id, student_id, consent_type, verified_by_admin_id, verified_at, expires_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: signup_requests; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".signup_requests (id, persona, full_name, mobile, email, password_hash, address_line1, address_line2, city, state, pincode, country, sponsor_type, pan_number, company_name, company_registration_number, gst_number, authorized_signatory_name, authorized_signatory_designation, business_name, business_type, product_categories, website, date_of_birth, school_or_college_name, grade_or_year, guardian_name, guardian_mobile, kyc_status, admin_note, created_at, updated_at) FROM stdin;
d0bf206f-61e6-4b94-8312-61c8809f3187	sponsor	harsh	9216328056	harsh1@gmail.com	$2b$12$Gvx.R4wZggbiaP9g8jJjdeHxdZAptNwjLVmS/lZzZDPcAN0ud0ZlO	29a	0	Jaipur	Rajasthan	302013	India	individual	ABCDEF2002	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	approved	All documents verified. Approved.	2026-03-19 11:05:14.963438+00	2026-03-19 11:23:13.347705+00
e8746f11-542b-4a1e-8880-3ce8c5d6f84b	student	Test User 1	1234567890	test1@gmail.com	$2b$12$8WZ/oAcaRyVCll.A9JNiieRr3aeFGBJ0ld0bLudP4WZHVYM1XSLuK	address	address	city	state	12345	Country	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	approved	\N	2026-03-19 17:25:56.701054+00	2026-03-19 17:25:56.701054+00
89c1ad50-a73e-4f02-8e61-1c14a37343ea	student	Test User 2	1234567890	test2@gmail.com	$2b$12$YMvDB9ZjFnVHVVUlvGVV3OCrTZlRKv/./vJsEdYy1gW9Z8gbeveqe	address	address	city	state	12345	Country	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	approved	\N	2026-03-19 17:25:56.911985+00	2026-03-19 17:25:56.911985+00
01c3110c-8b3f-44b9-96cf-c119f937dcdc	student	Test User 3	1234567890	test3@gmail.com	$2b$12$B7C0YzpA4.nsuuUNFvw56OD8254Xoo2bL98S748c8XQV3dwfv5bEG	address	address	city	state	12345	Country	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	approved	\N	2026-03-19 17:25:57.116267+00	2026-03-19 17:25:57.116267+00
0ddbc297-568f-41c8-9159-4424e517faf9	student	Test User 4	1234567890	test4@gmail.com	$2b$12$vodRjtuM4q1QhCWKSMd.uuPO/ClDPvgvNk8cI1PkNgbKxymItNY4q	address	address	city	state	12345	Country	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	approved	\N	2026-03-19 17:25:57.318617+00	2026-03-19 17:25:57.318617+00
2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	student	Test User 5	1234567890	test5@gmail.com	$2b$12$nChPsvVGj32aKcWsZUa7n.Lnhx/1cdxThpbuELcBkIgkTAErfYi.2	address	address	city	state	12345	Country	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	approved	\N	2026-03-19 17:25:57.520932+00	2026-03-19 17:25:57.520932+00
96bbf32a-eef0-43e4-9526-220295705dbf	sponsor	harsh	9216328056	harsh@gmail.com	$2b$12$xy6hzlPAmlfvXODMh0NXV.sgw983lJNIGjpffo9qLDNYt0lHc71OW	29a	0	Jaipur	Rajasthan	302013	India	individual	ABCDEF2002	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	approved	All documents verified. Approved.	2026-03-19 10:47:15.435216+00	2026-03-19 11:00:39.385464+00
\.


--
-- Data for Name: sos_reports; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".sos_reports (id, message_id, reporter_persona_id, hidden_at, admin_notified_at, resolved_at, notes, created_at) FROM stdin;
793b7481-03dd-4b8e-b9bf-5d68e562168b	03972879-c030-4fd9-ad13-de6bc3170054	74067a42-7a31-4094-936b-3a703429a972	2026-03-19 18:38:16.762311+00	\N	2026-03-19 18:38:23.9586+00	\N	2026-03-19 18:38:16.764842+00
adb4a69b-e15b-4149-8f21-eac1a5bf2d7a	1ae40fca-a203-474f-bc68-7395f9fbbfda	3566731e-6660-4385-bd6f-8aef9903eb59	2026-03-19 18:31:30.980099+00	\N	2026-03-19 18:38:24.839986+00	\N	2026-03-19 18:31:30.981104+00
a39530d4-1aff-4a6a-b2b6-8fbfcb676242	a0800cd3-6ab6-4ee7-8e6c-8276b9a8d93d	3566731e-6660-4385-bd6f-8aef9903eb59	2026-03-19 18:30:51.279036+00	\N	2026-03-19 18:38:25.252009+00	\N	2026-03-19 18:30:51.281057+00
342039eb-b7b6-4723-bbd4-e3993573cf26	5e778a38-f8c4-4d16-b7da-30388889c562	3566731e-6660-4385-bd6f-8aef9903eb59	2026-03-19 18:26:34.501412+00	\N	2026-03-19 18:38:26.092677+00	\N	2026-03-19 18:26:34.502419+00
2d4b2698-11a8-47d8-8aad-d090daf8af71	50a5f829-7c5c-479f-980d-b9855c65c074	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 18:24:23.520087+00	\N	2026-03-19 18:38:27.077786+00	\N	2026-03-19 18:24:23.523963+00
f70833c2-fd6d-468f-be16-358222bc7b8c	13af68db-24c8-4de8-82ad-a926f0329908	3566731e-6660-4385-bd6f-8aef9903eb59	2026-03-19 18:21:46.955812+00	\N	2026-03-19 18:38:29.20574+00	\N	2026-03-19 18:21:46.957805+00
a00954a2-157c-4cd2-86a4-2ae6c68619ea	651f0416-cba1-487e-8274-a7574b23091c	3566731e-6660-4385-bd6f-8aef9903eb59	2026-03-19 18:39:57.646988+00	\N	2026-03-19 18:40:29.299173+00	\N	2026-03-19 18:39:57.646988+00
cc0ea0df-32e3-4c42-8c24-90442195baa1	4d86221a-b6c5-45a7-8206-3de2c45d093a	74067a42-7a31-4094-936b-3a703429a972	2026-03-19 18:42:01.72508+00	\N	2026-03-19 18:44:08.981058+00	\N	2026-03-19 18:42:01.727662+00
facc5be4-ca34-42b1-9e9f-48344a1cbdc2	9a691be5-fb32-450e-8f35-08a6828e5549	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 19:52:09.299336+00	\N	2026-03-19 19:52:15.524717+00	\N	2026-03-19 19:52:09.301348+00
48d677fc-98d1-4441-8d80-196e5fef72c1	cebeff68-2bfe-4f5e-8c65-208ae44c7b24	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 19:59:47.195997+00	\N	2026-03-19 19:59:53.234264+00	\N	2026-03-19 19:59:47.198005+00
46e2ecdd-0ebd-450a-ae11-f0fa9e1aa1c5	e11a0c2a-6698-4e5c-a5bc-5170c3cb117e	74067a42-7a31-4094-936b-3a703429a972	2026-03-19 18:39:09.978973+00	\N	2026-03-19 20:25:15.177482+00	\N	2026-03-19 18:39:09.979995+00
94de7f71-26d9-4ed2-8a3d-ba3a5144dfd4	379e8429-6f27-42c9-ae46-f7bce5d6bbe6	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 20:45:45.080625+00	\N	2026-03-19 20:46:05.167615+00	\N	2026-03-19 20:45:45.094069+00
4645cecb-c8d0-4148-9ed6-423800f62df8	9738040d-fecf-484a-bd86-b50f6a2391d8	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 20:48:24.185244+00	\N	2026-03-19 20:50:29.374858+00	\N	2026-03-19 20:48:24.186755+00
1681c258-8716-4d3f-9227-e587a1879fa9	4f66a223-93f3-4d03-bcfa-2cf6b249e9ed	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 20:57:35.878896+00	\N	2026-03-19 20:57:43.440439+00	\N	2026-03-19 20:57:35.88056+00
c6fba97c-67cf-4194-a5da-9bffdfa3ee7d	e1f4a04e-95f0-4492-acbe-26e5cf4ab2c2	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 21:02:01.399601+00	\N	2026-03-19 21:03:41.058264+00	\N	2026-03-19 21:02:01.40215+00
6fa559ec-95bc-4ef3-bf78-f0d5c23fddac	3ce65e24-a597-4d5a-b343-1b9faefa1801	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 21:04:05.02162+00	\N	2026-03-19 21:08:59.485847+00	\N	2026-03-19 21:04:05.02413+00
8d0079b7-de2a-4d6b-93b6-fe376eea2bd0	4a8b327f-81d6-40bf-bdde-b68650870ad7	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 21:09:43.565062+00	\N	2026-03-19 21:09:51.610729+00	\N	2026-03-19 21:09:43.567062+00
ffbb18e1-01d1-4355-8c4a-3809ba0af5c7	2879fe6f-402c-4b78-805d-d41122c44342	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 21:17:38.230525+00	\N	2026-03-19 21:17:45.649663+00	\N	2026-03-19 21:17:38.238614+00
c4404569-40c1-4d85-90ca-11dadb54851e	1fc49983-19c9-4559-8691-5aacb0d407e4	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-19 21:23:25.674692+00	\N	\N	\N	2026-03-19 21:23:25.675699+00
f402d911-fb80-451e-94a5-2ff837432e7c	8030cf4e-9ed3-4ccb-bce8-e97269a784a5	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-23 15:51:32.671628+00	\N	2026-03-23 16:10:32.180335+00	\N	2026-03-23 15:51:32.683664+00
482ab194-f24d-4392-83a7-616e02396409	a79772e7-38ab-4284-b6ff-28a31f9a7488	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-23 16:13:36.92552+00	\N	2026-03-23 16:14:03.348261+00	\N	2026-03-23 16:13:36.927522+00
a5b6e87e-5c3d-4b64-9337-48bcd0814c3d	8e463f25-819a-4ba0-b198-12eb0131cb15	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-23 16:11:38.676176+00	\N	2026-03-23 16:22:29.851799+00	\N	2026-03-23 16:11:38.679685+00
e4b107c9-51c0-4979-a8e7-4ecd245d402d	e1ae6836-d801-4bfc-a970-e1a49a9fb66a	c17ce59c-9328-41da-9df9-f545c92fa2e1	2026-03-23 16:23:08.322946+00	\N	2026-03-23 16:23:18.452462+00	\N	2026-03-23 16:23:08.325454+00
4faf33e0-8af9-4a9b-a5b5-e37933b7a552	86f7a197-e036-438b-8b47-b10cb4800bf3	74067a42-7a31-4094-936b-3a703429a972	2026-03-23 16:37:21.567262+00	\N	\N	\N	2026-03-23 16:37:21.568773+00
b003fa55-2e4f-44c9-bd00-ad2c693cac51	52b45e9c-2c08-4f2b-8028-039a9c918a96	c17ce59c-9328-41da-9df9-f545c92fa2e1	2026-03-23 16:37:54.711408+00	\N	2026-03-23 16:37:59.572882+00	\N	2026-03-23 16:37:54.712924+00
0badaf16-053d-4132-a895-6ae035b8f92c	0b274955-917f-49f3-a257-60e6a18a00b6	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-24 04:50:34.89942+00	\N	\N	\N	2026-03-24 04:50:34.909538+00
26522ca4-7ccb-4604-b032-bbc1daa16b31	43f7cc75-3dcb-4650-a0e8-2f2b0eea3955	e3ef1c6a-5f0e-4fae-90e7-c222c00a9987	2026-03-24 04:51:10.497876+00	\N	2026-03-24 04:51:16.171693+00	\N	2026-03-24 04:51:10.498877+00
a0084d83-618c-4da9-a47f-2166a08fa9cb	53708eac-3d03-46cf-bb4f-3545fabe61b9	c17ce59c-9328-41da-9df9-f545c92fa2e1	2026-03-24 05:30:06.74701+00	\N	2026-03-24 05:30:18.669755+00	\N	2026-03-24 05:30:06.74901+00
eea7479a-aeca-4b0a-a66f-a9ccede022ed	b082b050-b1ca-4024-a9f5-44f615912cd2	81bfbce8-f290-4772-8ef2-c432eaa49a32	2026-03-25 13:15:11.83046+00	\N	2026-03-25 13:15:24.372019+00	\N	2026-03-25 13:15:11.860422+00
594455ce-af24-4dfb-a405-554cf3cb5350	783b0b98-a69b-486d-84ef-39e2b35b08fc	74067a42-7a31-4094-936b-3a703429a972	2026-03-25 15:52:15.502069+00	\N	2026-03-25 15:52:29.610005+00	\N	2026-03-25 15:52:15.503124+00
d54ee49b-96e8-4505-990a-9f1be160b321	7b7fd710-acb0-4882-84a7-85b8a13ff04b	74067a42-7a31-4094-936b-3a703429a972	2026-03-31 07:49:21.20272+00	\N	2026-03-31 07:49:26.577454+00	\N	2026-03-31 07:49:21.207112+00
eee204a0-a8a7-4763-a686-b9d32b726e2d	1ef2a822-59ce-45e7-9dfd-e7852aa9f2c3	c17ce59c-9328-41da-9df9-f545c92fa2e1	2026-03-30 16:42:54.043142+00	\N	2026-03-31 11:37:24.228617+00	\N	2026-03-30 16:42:54.051921+00
3b160ce7-db7a-4f4a-8b4b-c7c1f5da42ee	61425d33-e5ee-4555-aadc-4518d70e784e	74067a42-7a31-4094-936b-3a703429a972	2026-03-24 17:00:19.387956+00	\N	2026-03-31 11:37:25.833674+00	\N	2026-03-24 17:00:19.390483+00
\.


--
-- Data for Name: sponsor_circles; Type: TABLE DATA; Schema: ZENK; Owner: neondb_owner
--

COPY "ZENK".sponsor_circles (id, name, description, status, created_at) FROM stdin;
481eba8f-778d-4618-8f9e-6e6b263d89a0	Test Circle	A circle for testing.	active	2026-03-19 16:22:40.645374+00
\.


--
-- Data for Name: admin_access_log; Type: TABLE DATA; Schema: audit; Owner: neondb_owner
--

COPY audit.admin_access_log (id, admin_id, action, target_table, target_id, changes_json, created_at) FROM stdin;
80a5176d-e50b-43a2-bd67-f5533863a3ff	89c1ad50-a73e-4f02-8e61-1c14a37343ea	INSERT	chat_bans	c8bc493e-4999-4d4b-b523-2ca2b16ae602	{"id": "c8bc493e-4999-4d4b-b523-2ca2b16ae602", "reason": "inapt", "user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-19T23:26:23.521973+05:30", "banned_by_admin_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea"}	2026-03-19 12:26:23.517915+00
184fafe9-f444-49b1-828a-af6b60164530	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	83b29ee6-1106-4269-9987-d1be8af5011d	{"id": "83b29ee6-1106-4269-9987-d1be8af5011d", "reason": "2", "user_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-19T23:29:00.187125+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b"}	2026-03-19 12:29:00.183463+00
6926e536-0ecc-4f45-9009-d6247ce0261f	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	83b29ee6-1106-4269-9987-d1be8af5011d	null	2026-03-19 12:30:35.601967+00
b331f78b-f030-4745-9528-dfd354de6c0e	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	c8bc493e-4999-4d4b-b523-2ca2b16ae602	null	2026-03-19 12:36:28.809751+00
ad243c65-33ea-4ed2-83a8-9c8f8b1f1309	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	26d639c0-1305-4e55-9ebc-3e0d2e08644a	{"id": "26d639c0-1305-4e55-9ebc-3e0d2e08644a", "reason": "TestPass1!\\n", "user_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-19T23:58:33.689589+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": null}	2026-03-19 12:58:33.679277+00
d419c2e6-650f-4a32-acf8-faa9a6070b01	89c1ad50-a73e-4f02-8e61-1c14a37343ea	INSERT	chat_bans	31894c09-7094-41d9-8519-2b7e07d6670c	{"id": "31894c09-7094-41d9-8519-2b7e07d6670c", "reason": "Policy violation found in report", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T00:10:27.5323+05:30", "banned_by_admin_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "reported_message_content": null}	2026-03-19 13:10:27.529456+00
e525f82d-bc0a-4790-81bf-b6310d9399d5	89c1ad50-a73e-4f02-8e61-1c14a37343ea	DELETE	chat_bans	31894c09-7094-41d9-8519-2b7e07d6670c	null	2026-03-19 13:10:35.71982+00
45a7ac9a-3f98-4513-9710-62613ebb756f	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	26d639c0-1305-4e55-9ebc-3e0d2e08644a	null	2026-03-19 14:20:51.192771+00
a958a00b-ed91-4ed0-9381-bfe20f9dba2a	89c1ad50-a73e-4f02-8e61-1c14a37343ea	INSERT	chat_bans	b9f3f995-d7af-4cf1-9dea-38603017d105	{"id": "b9f3f995-d7af-4cf1-9dea-38603017d105", "reason": "Policy violation found in report", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T01:22:14.522757+05:30", "banned_by_admin_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "reported_message_content": "user2 from circle 2"}	2026-03-19 14:22:14.520799+00
261ec3fc-1c66-48a6-90ef-8e4f67cb6fdf	89c1ad50-a73e-4f02-8e61-1c14a37343ea	DELETE	chat_bans	b9f3f995-d7af-4cf1-9dea-38603017d105	null	2026-03-19 14:22:22.807761+00
83255396-c570-45fc-a44b-141c1bde62c8	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	2b6bb281-a2f1-43e6-88b2-6a5e530d7e8a	{"id": "2b6bb281-a2f1-43e6-88b2-6a5e530d7e8a", "reason": "content", "user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T01:23:47.368008+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": null}	2026-03-19 14:23:47.366601+00
2e9e3c3c-805a-41b5-8755-ce73a1bc2db8	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	2b6bb281-a2f1-43e6-88b2-6a5e530d7e8a	null	2026-03-19 14:23:52.234541+00
425882b6-0269-42ed-8c1b-07885c913c4e	01c3110c-8b3f-44b9-96cf-c119f937dcdc	INSERT	chat_bans	7a464665-feea-44db-811a-39a86968e815	{"id": "7a464665-feea-44db-811a-39a86968e815", "reason": "Policy violation found in report", "user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T01:29:52.180602+05:30", "banned_by_admin_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "reported_message_content": "whatsapp me"}	2026-03-19 14:29:52.178101+00
a23cec13-e576-43b2-9e3a-ad88951cc52f	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	7a464665-feea-44db-811a-39a86968e815	null	2026-03-19 14:30:19.229275+00
1800a7a3-c5b6-4a22-9267-fb0dd947a309	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	8657fbf3-c7f0-4ea4-b0c6-5877766dbb68	{"id": "8657fbf3-c7f0-4ea4-b0c6-5877766dbb68", "reason": "Policy violation found in report", "user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T01:55:13.720109+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": "this is test user 4"}	2026-03-19 14:55:13.708665+00
210409db-a290-4f4d-b9dc-5c3dc904edd6	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	87e87805-251f-4340-a92f-eca825cb4465	{"id": "87e87805-251f-4340-a92f-eca825cb4465", "reason": "Policy violation found in report", "user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T02:20:27.645177+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": "here is my number 1234565"}	2026-03-19 15:20:27.640107+00
98630f98-5838-405b-8f30-be63096f5c85	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	CREATE_BAN	chat_bans	87e87805-251f-4340-a92f-eca825cb4465	{"reason": "Policy violation found in report", "user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-19 20:50:27.640107+00
10a4c4e7-a98e-410b-ab35-167575fda134	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	87e87805-251f-4340-a92f-eca825cb4465	null	2026-03-19 15:20:37.718627+00
f2124d14-0638-446f-9f5d-efeb776e2883	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	REVOKE_BAN	chat_bans	87e87805-251f-4340-a92f-eca825cb4465	{"user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-19 20:50:37.718627+00
dc3756b9-0645-4036-9674-2c1aa8b2a5be	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	1c4c98fa-d4ce-4620-974e-66dd33bde7a9	{"id": "1c4c98fa-d4ce-4620-974e-66dd33bde7a9", "reason": "Policy violation found in report", "user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T02:32:05.405634+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": "lets conmnect on instagram"}	2026-03-19 15:32:05.402656+00
bf6dcc0e-5955-44d5-9550-905da72713a1	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	CREATE_BAN	chat_bans	1c4c98fa-d4ce-4620-974e-66dd33bde7a9	{"reason": "Policy violation found in report", "user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-19 21:02:05.402656+00
b801d6a4-4772-413f-873d-6e8b278b593f	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	RESOLVE_REPORT	sos_reports	c6fba97c-67cf-4194-a5da-9bffdfa3ee7d	"{\\"resolved\\": true}"	2026-03-19 21:03:41.058264+00
6dbd9178-37b2-4e0b-a709-6016f6cd1bd6	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	8657fbf3-c7f0-4ea4-b0c6-5877766dbb68	null	2026-03-19 15:34:24.580019+00
dc4b6e29-2af9-4113-8a8f-02da88faf2e1	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	REVOKE_BAN	chat_bans	8657fbf3-c7f0-4ea4-b0c6-5877766dbb68	{"user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-19 21:04:24.580019+00
eef9cf17-ce9a-4f7a-9e27-744d226d24ed	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	RESOLVE_REPORT	sos_reports	6fa559ec-95bc-4ef3-bf78-f0d5c23fddac	{"resolved": true}	2026-03-19 21:08:59.48737+00
ded10e29-c6f6-4c85-a470-18ab83fbd481	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	ff5e6840-aa5f-4615-a5d9-5cec9486706c	{"id": "ff5e6840-aa5f-4615-a5d9-5cec9486706c", "reason": "Policy violation found in report", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T02:39:49.834943+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": null}	2026-03-19 15:39:49.831683+00
c0062d9d-bfc3-4eb0-9d6a-415dd19ad2ce	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	CREATE_BAN	chat_bans	ff5e6840-aa5f-4615-a5d9-5cec9486706c	{"reason": "Policy violation found in report", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-19 21:09:49.831683+00
c7d32be5-fff9-4f20-aab0-c2afeba81788	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	RESOLVE_REPORT	sos_reports	8d0079b7-de2a-4d6b-93b6-fe376eea2bd0	{"resolved": true}	2026-03-19 21:09:51.612247+00
97d90f53-8500-439e-b168-c35fbdbf24db	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	0e90b08f-5688-4aa1-84fd-c4b7490e7aa8	{"id": "0e90b08f-5688-4aa1-84fd-c4b7490e7aa8", "reason": "Policy violation found in report", "user_id": "96bbf32a-eef0-43e4-9526-220295705dbf", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-20T02:47:44.208083+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": null}	2026-03-19 15:47:44.195709+00
3927411b-39f3-42c1-9a3f-3e5f7b4b3de2	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	CREATE_BAN	chat_bans	0e90b08f-5688-4aa1-84fd-c4b7490e7aa8	{"reason": "Policy violation found in report", "user_id": "96bbf32a-eef0-43e4-9526-220295705dbf", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-19 21:17:44.195709+00
dce3cf0b-c27c-4f79-8c3a-a8eaa3484bf9	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	RESOLVE_REPORT	sos_reports	ffbb18e1-01d1-4355-8c4a-3809ba0af5c7	{"resolved": true}	2026-03-19 21:17:45.651179+00
725eccb9-f205-44e6-badc-2a4e1b3cc148	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	1c4c98fa-d4ce-4620-974e-66dd33bde7a9	null	2026-03-19 15:53:12.715158+00
8213c76a-cbff-4b18-8045-31cdd823d62f	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	REVOKE_BAN	chat_bans	1c4c98fa-d4ce-4620-974e-66dd33bde7a9	{"user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-19 21:23:12.715158+00
17f14d1f-81a1-47e6-b555-0ed79d7d9710	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	RESOLVE_REPORT	sos_reports	f402d911-fb80-451e-94a5-2ff837432e7c	{"resolved": true}	2026-03-23 16:10:32.181351+00
7e3cc1f9-7941-4a10-82e1-588bc2abc24e	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	RESOLVE_REPORT	sos_reports	482ab194-f24d-4392-83a7-616e02396409	{"resolved": true}	2026-03-23 16:14:03.34978+00
6e5820bb-b438-4a83-961f-527d23a3bfdf	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	RESOLVE_REPORT	sos_reports	a5b6e87e-5c3d-4b64-9337-48bcd0814c3d	{"resolved": true}	2026-03-23 16:22:29.852849+00
92e19a86-b7fa-4467-a447-01f4ce6ff5cc	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	INSERT	chat_bans	6147ae21-3404-4f81-8676-485fcace4e38	{"id": "6147ae21-3404-4f81-8676-485fcace4e38", "reason": "Policy violation found in report", "user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-23T21:53:15.001748+05:30", "banned_by_admin_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "reported_message_content": "lets connect on instagram"}	2026-03-23 10:53:14.999392+00
1002645b-950a-4477-ace5-b20ef1c2ef1e	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	CREATE_BAN	chat_bans	6147ae21-3404-4f81-8676-485fcace4e38	{"reason": "Policy violation found in report", "user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-23 16:23:14.999392+00
9b30972a-4488-4ef3-9fd5-fd0eeda110bf	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	RESOLVE_REPORT	sos_reports	e4b107c9-51c0-4979-a8e7-4ecd245d402d	{"resolved": true}	2026-03-23 16:23:18.452462+00
47dcd043-536c-431a-bdb1-5c8083e0d6aa	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	DELETE	chat_bans	0e90b08f-5688-4aa1-84fd-c4b7490e7aa8	null	2026-03-23 10:53:36.84597+00
7a27c674-6f68-48db-92b1-167cc0dfeede	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	REVOKE_BAN	chat_bans	0e90b08f-5688-4aa1-84fd-c4b7490e7aa8	{"user_id": "96bbf32a-eef0-43e4-9526-220295705dbf", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-23 16:23:36.84597+00
54452cfc-9693-4444-9caf-0ca968a093ce	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	ff5e6840-aa5f-4615-a5d9-5cec9486706c	null	2026-03-23 11:06:30.533239+00
c5b1f7a4-bbaf-4e62-89fe-737f7f97562e	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	REVOKE_BAN	chat_bans	ff5e6840-aa5f-4615-a5d9-5cec9486706c	{"user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-23 16:36:30.533239+00
0321f95a-6faf-4a51-b6b5-8e6cf403846c	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	43d8def6-29f7-4d06-adde-c159e5c63234	{"id": "43d8def6-29f7-4d06-adde-c159e5c63234", "reason": "inapt", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-23T22:06:33.921491+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": null}	2026-03-23 11:06:33.919051+00
dd28fa75-f95c-4b7d-ac00-141e18b05bd8	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	CREATE_BAN	chat_bans	43d8def6-29f7-4d06-adde-c159e5c63234	{"reason": "inapt", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-23 16:36:33.919051+00
5ff50c77-bf30-480f-9f17-0a36425a86bd	89c1ad50-a73e-4f02-8e61-1c14a37343ea	DELETE	chat_bans	43d8def6-29f7-4d06-adde-c159e5c63234	null	2026-03-23 11:07:10.996895+00
d58ede99-271a-4b4d-a621-749b5f336165	89c1ad50-a73e-4f02-8e61-1c14a37343ea	REVOKE_BAN	chat_bans	43d8def6-29f7-4d06-adde-c159e5c63234	{"user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-23 16:37:10.996895+00
93488233-9dbf-4bd5-ac9e-ca28963b9658	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	INSERT	chat_bans	d8dc6842-99ac-43e9-9db1-a84dac53c681	{"id": "d8dc6842-99ac-43e9-9db1-a84dac53c681", "reason": "Policy violation found in report", "user_id": "96bbf32a-eef0-43e4-9526-220295705dbf", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-23T22:07:58.076141+05:30", "banned_by_admin_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "reported_message_content": "hello"}	2026-03-23 11:07:58.074624+00
842ab53d-0664-4778-babb-2c4d5532d0af	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	CREATE_BAN	chat_bans	d8dc6842-99ac-43e9-9db1-a84dac53c681	{"reason": "Policy violation found in report", "user_id": "96bbf32a-eef0-43e4-9526-220295705dbf", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-23 16:37:58.074624+00
ba8aaf6a-842c-464a-a4e5-483406532985	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	RESOLVE_REPORT	sos_reports	b003fa55-2e4f-44c9-bd00-ad2c693cac51	{"resolved": true}	2026-03-23 16:37:59.574387+00
718fac73-33f4-4cf7-9bc9-7d54f6194488	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	c1e6781c-f546-4822-a487-ac9dddd4e3ef	{"id": "c1e6781c-f546-4822-a487-ac9dddd4e3ef", "reason": "Policy violation found in report", "user_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-24T10:21:14.661358+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": null}	2026-03-23 23:21:14.657003+00
3c22ff49-7d4b-4e3b-9886-846cf4f33340	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	CREATE_BAN	chat_bans	c1e6781c-f546-4822-a487-ac9dddd4e3ef	{"reason": "Policy violation found in report", "user_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-24 04:51:14.657003+00
c582c91e-ed40-4551-962a-8adea23e8b95	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	RESOLVE_REPORT	sos_reports	26522ca4-7ccb-4604-b032-bbc1daa16b31	{"resolved": true}	2026-03-24 04:51:16.171693+00
10526be0-85d0-45be-a6f5-ab4c99a3e50c	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	6147ae21-3404-4f81-8676-485fcace4e38	null	2026-03-23 23:21:27.214399+00
db9885e6-e4f7-4c02-9a4f-d3b5dfb2db61	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	REVOKE_BAN	chat_bans	6147ae21-3404-4f81-8676-485fcace4e38	{"user_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-24 04:51:27.214399+00
112fbb8c-1cff-478c-8eae-5696e7a2b562	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	DELETE	chat_bans	c1e6781c-f546-4822-a487-ac9dddd4e3ef	null	2026-03-23 23:22:04.985819+00
73d5bf0e-4c7d-49f2-a45e-00fa6ee6d878	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	REVOKE_BAN	chat_bans	c1e6781c-f546-4822-a487-ac9dddd4e3ef	{"user_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-24 04:52:04.985819+00
13b42aae-e94f-4d3e-a961-eab2565d4565	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	INSERT	chat_bans	1605b404-36c4-4b7b-98d1-03e1a8acb716	{"id": "1605b404-36c4-4b7b-98d1-03e1a8acb716", "reason": "Policy violation found in report", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-24T11:00:17.022362+05:30", "banned_by_admin_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "reported_message_content": "lets connect on instagram"}	2026-03-24 00:00:17.021717+00
c4de58f1-9678-4e9b-8349-3af8a0511131	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	CREATE_BAN	chat_bans	1605b404-36c4-4b7b-98d1-03e1a8acb716	{"reason": "Policy violation found in report", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-24 05:30:17.021717+00
55ca6d1d-e040-406a-adc3-cdcb3bc84303	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	RESOLVE_REPORT	sos_reports	a0084d83-618c-4da9-a47f-2166a08fa9cb	{"resolved": true}	2026-03-24 05:30:18.670761+00
2bb5d0b3-8487-40e3-b31a-a020ebdeb3e2	89c1ad50-a73e-4f02-8e61-1c14a37343ea	DELETE	chat_bans	1605b404-36c4-4b7b-98d1-03e1a8acb716	null	2026-03-24 11:22:46.223426+00
3edebe20-defe-4374-9f94-de1dc7dec66a	89c1ad50-a73e-4f02-8e61-1c14a37343ea	REVOKE_BAN	chat_bans	1605b404-36c4-4b7b-98d1-03e1a8acb716	{"user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-24 16:52:46.223426+00
0d7e939c-99c0-41be-8e19-42e4f66ee36a	01c3110c-8b3f-44b9-96cf-c119f937dcdc	INSERT	chat_bans	8b38dc79-a964-44a0-8e10-59e05aaa2b46	{"id": "8b38dc79-a964-44a0-8e10-59e05aaa2b46", "reason": "Policy violation found in report ", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-25T18:45:23.011543+05:30", "banned_by_admin_id": "01c3110c-8b3f-44b9-96cf-c119f937dcdc", "reported_message_content": "lets connect on insagram"}	2026-03-25 07:45:22.983578+00
1510fa20-ee62-4c02-aa5b-cb3d81899e4b	01c3110c-8b3f-44b9-96cf-c119f937dcdc	CREATE_BAN	chat_bans	8b38dc79-a964-44a0-8e10-59e05aaa2b46	{"reason": "Policy violation found in report ", "user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-25 13:15:22.983578+00
f2e8c07f-4765-4557-a88f-89f5cc408718	01c3110c-8b3f-44b9-96cf-c119f937dcdc	RESOLVE_REPORT	sos_reports	eea7479a-aeca-4b0a-a66f-a9ccede022ed	{"resolved": true}	2026-03-25 13:15:24.375041+00
8906c6a7-1276-455d-93cc-108390a83bbb	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	8b38dc79-a964-44a0-8e10-59e05aaa2b46	null	2026-03-25 07:59:37.53299+00
dd280c31-7c26-4fec-b38b-6ca9f58bb965	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	REVOKE_BAN	chat_bans	8b38dc79-a964-44a0-8e10-59e05aaa2b46	{"user_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-25 13:29:37.53299+00
7b87ea7f-9b8c-4e49-8920-d4d970d56eb8	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	INSERT	chat_bans	ae5c0abf-dd22-46e7-972d-5309da15d880	{"id": "ae5c0abf-dd22-46e7-972d-5309da15d880", "reason": "apt", "user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-25T19:03:17.127401+05:30", "banned_by_admin_id": "e8746f11-542b-4a1e-8880-3ce8c5d6f84b", "reported_message_content": null}	2026-03-25 08:03:17.125754+00
45803c24-988a-453b-a860-6794a4d5a8f2	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	CREATE_BAN	chat_bans	ae5c0abf-dd22-46e7-972d-5309da15d880	{"reason": "apt", "user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-25 13:33:17.125754+00
202bf284-0567-411c-a679-23826fcefbce	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	DELETE	chat_bans	ae5c0abf-dd22-46e7-972d-5309da15d880	null	2026-03-25 08:08:03.846455+00
2d9feaa2-d7a1-4469-a904-65d58aef6bd3	e8746f11-542b-4a1e-8880-3ce8c5d6f84b	REVOKE_BAN	chat_bans	ae5c0abf-dd22-46e7-972d-5309da15d880	{"user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-25 13:38:03.846455+00
48f3ef32-1c18-4caf-b40e-53fb65db4076	89c1ad50-a73e-4f02-8e61-1c14a37343ea	INSERT	chat_bans	0e62abc8-2aef-4da6-84e7-6140890a221c	{"id": "0e62abc8-2aef-4da6-84e7-6140890a221c", "reason": "Policy violation found in report", "user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-25T21:22:28.373271+05:30", "banned_by_admin_id": "89c1ad50-a73e-4f02-8e61-1c14a37343ea", "reported_message_content": "lets connect on instagram"}	2026-03-25 10:22:28.370712+00
fd432c42-69fe-44a9-9664-fbf733bda7ef	89c1ad50-a73e-4f02-8e61-1c14a37343ea	CREATE_BAN	chat_bans	0e62abc8-2aef-4da6-84e7-6140890a221c	{"reason": "Policy violation found in report", "user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-25 15:52:28.370712+00
d444b47f-c11c-4ca0-aba7-9d2e380a167f	89c1ad50-a73e-4f02-8e61-1c14a37343ea	RESOLVE_REPORT	sos_reports	594455ce-af24-4dfb-a405-554cf3cb5350	{"resolved": true}	2026-03-25 15:52:29.610005+00
4eb41cf1-4b49-4b93-a707-37af42dfb77b	0ddbc297-568f-41c8-9159-4424e517faf9	DELETE	chat_bans	0e62abc8-2aef-4da6-84e7-6140890a221c	null	2026-03-29 08:19:25.928603+00
5eda900c-6c41-4c44-8e7b-8046cff8eb18	0ddbc297-568f-41c8-9159-4424e517faf9	REVOKE_BAN	chat_bans	0e62abc8-2aef-4da6-84e7-6140890a221c	{"user_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-29 13:49:25.928603+00
b4cd1de9-bbbb-4b8d-b13a-f91c14c3c466	0ddbc297-568f-41c8-9159-4424e517faf9	INSERT	chat_bans	19a397fd-3651-4399-ada5-f45aeeba291a	{"id": "19a397fd-3651-4399-ada5-f45aeeba291a", "reason": "TestUser5!", "user_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0", "created_at": "2026-03-30T13:37:17.954654+05:30", "banned_by_admin_id": "0ddbc297-568f-41c8-9159-4424e517faf9", "reported_message_content": null}	2026-03-30 02:37:17.952065+00
6269d255-b5cf-4204-a62b-c30554faa70e	0ddbc297-568f-41c8-9159-4424e517faf9	CREATE_BAN	chat_bans	19a397fd-3651-4399-ada5-f45aeeba291a	{"reason": "TestUser5!", "user_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-30 08:07:17.952065+00
71f1025b-aef9-4a3b-aaa4-366b3b5d7fec	0ddbc297-568f-41c8-9159-4424e517faf9	DELETE	chat_bans	19a397fd-3651-4399-ada5-f45aeeba291a	null	2026-03-30 02:37:29.331254+00
554b7914-9b7b-41a4-9663-8987263b0a86	0ddbc297-568f-41c8-9159-4424e517faf9	REVOKE_BAN	chat_bans	19a397fd-3651-4399-ada5-f45aeeba291a	{"user_id": "2b850f8d-85d6-4d5f-a6e9-cd8a2a581633", "circle_id": "481eba8f-778d-4618-8f9e-6e6b263d89a0"}	2026-03-30 08:07:29.331254+00
2f8e0296-200e-4f30-a431-997264c5cb43	89c1ad50-a73e-4f02-8e61-1c14a37343ea	RESOLVE_REPORT	sos_reports	d54ee49b-96e8-4505-990a-9f1be160b321	{"resolved": true}	2026-03-31 07:49:26.578449+00
dcfb8f16-78cb-4377-b84f-26f320e7aef0	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	RESOLVE_REPORT	sos_reports	eee204a0-a8a7-4763-a686-b9d32b726e2d	{"resolved": true}	2026-03-31 11:37:24.229624+00
8b33bd6d-96de-49d5-a832-67b30c334cad	2b850f8d-85d6-4d5f-a6e9-cd8a2a581633	RESOLVE_REPORT	sos_reports	3b160ce7-db7a-4f4a-8b4b-c7c1f5da42ee	{"resolved": true}	2026-03-31 11:37:25.835185+00
\.


--
-- Data for Name: account; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.account (id, "accountId", "providerId", "userId", "accessToken", "refreshToken", "idToken", "accessTokenExpiresAt", "refreshTokenExpiresAt", scope, password, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invitation; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.invitation (id, "organizationId", email, role, status, "expiresAt", "createdAt", "inviterId") FROM stdin;
\.


--
-- Data for Name: jwks; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.jwks (id, "publicKey", "privateKey", "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: member; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.member (id, "organizationId", "userId", role, "createdAt") FROM stdin;
\.


--
-- Data for Name: organization; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.organization (id, name, slug, logo, "createdAt", metadata) FROM stdin;
\.


--
-- Data for Name: project_config; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.project_config (id, name, endpoint_id, created_at, updated_at, trusted_origins, social_providers, email_provider, email_and_password, allow_localhost, plugin_configs, webhook_config) FROM stdin;
4d3bfe69-7d59-43b4-b08c-b32c4002b90d	zenk_test	ep-restless-grass-a1zc0nq0	2026-04-03 14:56:25.634+00	2026-04-03 14:56:25.635+00	[]	[{"id": "google", "isShared": true}]	{"type": "shared"}	{"enabled": true, "disableSignUp": false, "emailVerificationMethod": "otp", "requireEmailVerification": false, "autoSignInAfterVerification": true, "sendVerificationEmailOnSignIn": false, "sendVerificationEmailOnSignUp": false}	t	{"organization": {"config": {"creatorRole": "owner", "membershipLimit": 100, "organizationLimit": 10, "sendInvitationEmail": false}, "enabled": true}}	{"enabled": false, "enabledEvents": [], "timeoutSeconds": 5}
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.session (id, "expiresAt", token, "createdAt", "updatedAt", "ipAddress", "userAgent", "userId", "impersonatedBy", "activeOrganizationId") FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth."user" (id, name, email, "emailVerified", image, "createdAt", "updatedAt", role, banned, "banReason", "banExpires") FROM stdin;
\.


--
-- Data for Name: verification; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.verification (id, identifier, value, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: chat_bans chat_bans_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_bans
    ADD CONSTRAINT chat_bans_pkey PRIMARY KEY (id);


--
-- Name: chat_channels chat_channels_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_channels
    ADD CONSTRAINT chat_channels_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: circle_members circle_members_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".circle_members
    ADD CONSTRAINT circle_members_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: gamified_personas gamified_personas_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".gamified_personas
    ADD CONSTRAINT gamified_personas_pkey PRIMARY KEY (id);


--
-- Name: kyc_documents kyc_documents_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".kyc_documents
    ADD CONSTRAINT kyc_documents_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: parental_consent_log parental_consent_log_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".parental_consent_log
    ADD CONSTRAINT parental_consent_log_pkey PRIMARY KEY (id);


--
-- Name: signup_requests signup_requests_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".signup_requests
    ADD CONSTRAINT signup_requests_pkey PRIMARY KEY (id);


--
-- Name: sos_reports sos_reports_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".sos_reports
    ADD CONSTRAINT sos_reports_pkey PRIMARY KEY (id);


--
-- Name: sponsor_circles sponsor_circles_pkey; Type: CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".sponsor_circles
    ADD CONSTRAINT sponsor_circles_pkey PRIMARY KEY (id);


--
-- Name: admin_access_log admin_access_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: neondb_owner
--

ALTER TABLE ONLY audit.admin_access_log
    ADD CONSTRAINT admin_access_log_pkey PRIMARY KEY (id);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: invitation invitation_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT invitation_pkey PRIMARY KEY (id);


--
-- Name: jwks jwks_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.jwks
    ADD CONSTRAINT jwks_pkey PRIMARY KEY (id);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: organization organization_slug_key; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.organization
    ADD CONSTRAINT organization_slug_key UNIQUE (slug);


--
-- Name: project_config project_config_endpoint_id_key; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.project_config
    ADD CONSTRAINT project_config_endpoint_id_key UNIQUE (endpoint_id);


--
-- Name: project_config project_config_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.project_config
    ADD CONSTRAINT project_config_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: session session_token_key; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT session_token_key UNIQUE (token);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: verification verification_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.verification
    ADD CONSTRAINT verification_pkey PRIMARY KEY (id);


--
-- Name: idx_chat_messages_channel_created; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX idx_chat_messages_channel_created ON "ZENK".chat_messages USING btree (channel_id, created_at DESC);


--
-- Name: idx_chat_messages_created; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX idx_chat_messages_created ON "ZENK".chat_messages USING btree (created_at DESC);


--
-- Name: idx_personas_nickname; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX idx_personas_nickname ON "ZENK".gamified_personas USING btree (nickname);


--
-- Name: ix_ZENK_chat_bans_circle_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_chat_bans_circle_id" ON "ZENK".chat_bans USING btree (circle_id);


--
-- Name: ix_ZENK_chat_bans_user_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_chat_bans_user_id" ON "ZENK".chat_bans USING btree (user_id);


--
-- Name: ix_ZENK_chat_channels_circle_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_chat_channels_circle_id" ON "ZENK".chat_channels USING btree (circle_id);


--
-- Name: ix_ZENK_chat_messages_channel_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_chat_messages_channel_id" ON "ZENK".chat_messages USING btree (channel_id);


--
-- Name: ix_ZENK_chat_messages_gamified_persona_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_chat_messages_gamified_persona_id" ON "ZENK".chat_messages USING btree (gamified_persona_id);


--
-- Name: ix_ZENK_circle_members_circle_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_circle_members_circle_id" ON "ZENK".circle_members USING btree (circle_id);


--
-- Name: ix_ZENK_circle_members_user_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_circle_members_user_id" ON "ZENK".circle_members USING btree (user_id);


--
-- Name: ix_ZENK_enrollments_circle_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_enrollments_circle_id" ON "ZENK".enrollments USING btree (circle_id);


--
-- Name: ix_ZENK_enrollments_user_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_enrollments_user_id" ON "ZENK".enrollments USING btree (user_id);


--
-- Name: ix_ZENK_gamified_personas_user_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE UNIQUE INDEX "ix_ZENK_gamified_personas_user_id" ON "ZENK".gamified_personas USING btree (user_id);


--
-- Name: ix_ZENK_kyc_documents_signup_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_kyc_documents_signup_id" ON "ZENK".kyc_documents USING btree (signup_id);


--
-- Name: ix_ZENK_notifications_recipient_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_notifications_recipient_id" ON "ZENK".notifications USING btree (recipient_id);


--
-- Name: ix_ZENK_sos_reports_message_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_sos_reports_message_id" ON "ZENK".sos_reports USING btree (message_id);


--
-- Name: ix_ZENK_sos_reports_reporter_persona_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX "ix_ZENK_sos_reports_reporter_persona_id" ON "ZENK".sos_reports USING btree (reporter_persona_id);


--
-- Name: ix_parental_consent_student_id; Type: INDEX; Schema: ZENK; Owner: neondb_owner
--

CREATE INDEX ix_parental_consent_student_id ON "ZENK".parental_consent_log USING btree (student_id);


--
-- Name: idx_admin_access_log_created; Type: INDEX; Schema: audit; Owner: neondb_owner
--

CREATE INDEX idx_admin_access_log_created ON audit.admin_access_log USING btree (created_at DESC);


--
-- Name: ix_audit_admin_access_log_admin_id; Type: INDEX; Schema: audit; Owner: neondb_owner
--

CREATE INDEX ix_audit_admin_access_log_admin_id ON audit.admin_access_log USING btree (admin_id);


--
-- Name: account_userId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "account_userId_idx" ON neon_auth.account USING btree ("userId");


--
-- Name: invitation_email_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX invitation_email_idx ON neon_auth.invitation USING btree (email);


--
-- Name: invitation_organizationId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "invitation_organizationId_idx" ON neon_auth.invitation USING btree ("organizationId");


--
-- Name: member_organizationId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "member_organizationId_idx" ON neon_auth.member USING btree ("organizationId");


--
-- Name: member_userId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "member_userId_idx" ON neon_auth.member USING btree ("userId");


--
-- Name: organization_slug_uidx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE UNIQUE INDEX organization_slug_uidx ON neon_auth.organization USING btree (slug);


--
-- Name: session_userId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "session_userId_idx" ON neon_auth.session USING btree ("userId");


--
-- Name: verification_identifier_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX verification_identifier_idx ON neon_auth.verification USING btree (identifier);


--
-- Name: chat_bans trg_log_chat_ban_activity; Type: TRIGGER; Schema: ZENK; Owner: neondb_owner
--

CREATE TRIGGER trg_log_chat_ban_activity AFTER INSERT OR DELETE ON "ZENK".chat_bans FOR EACH ROW EXECUTE FUNCTION "ZENK".log_chat_ban_activity();


--
-- Name: chat_bans chat_bans_banned_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_bans
    ADD CONSTRAINT chat_bans_banned_by_admin_id_fkey FOREIGN KEY (banned_by_admin_id) REFERENCES "ZENK".signup_requests(id) ON DELETE SET NULL;


--
-- Name: chat_bans chat_bans_circle_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_bans
    ADD CONSTRAINT chat_bans_circle_id_fkey FOREIGN KEY (circle_id) REFERENCES "ZENK".sponsor_circles(id) ON DELETE CASCADE;


--
-- Name: chat_bans chat_bans_user_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_bans
    ADD CONSTRAINT chat_bans_user_id_fkey FOREIGN KEY (user_id) REFERENCES "ZENK".signup_requests(id) ON DELETE CASCADE;


--
-- Name: chat_channels chat_channels_circle_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_channels
    ADD CONSTRAINT chat_channels_circle_id_fkey FOREIGN KEY (circle_id) REFERENCES "ZENK".sponsor_circles(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_channel_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_messages
    ADD CONSTRAINT chat_messages_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES "ZENK".chat_channels(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_gamified_persona_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".chat_messages
    ADD CONSTRAINT chat_messages_gamified_persona_id_fkey FOREIGN KEY (gamified_persona_id) REFERENCES "ZENK".gamified_personas(id) ON DELETE CASCADE;


--
-- Name: circle_members circle_members_circle_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".circle_members
    ADD CONSTRAINT circle_members_circle_id_fkey FOREIGN KEY (circle_id) REFERENCES "ZENK".sponsor_circles(id) ON DELETE CASCADE;


--
-- Name: circle_members circle_members_user_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".circle_members
    ADD CONSTRAINT circle_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES "ZENK".signup_requests(id) ON DELETE CASCADE;


--
-- Name: enrollments enrollments_circle_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".enrollments
    ADD CONSTRAINT enrollments_circle_id_fkey FOREIGN KEY (circle_id) REFERENCES "ZENK".sponsor_circles(id) ON DELETE CASCADE;


--
-- Name: enrollments enrollments_user_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".enrollments
    ADD CONSTRAINT enrollments_user_id_fkey FOREIGN KEY (user_id) REFERENCES "ZENK".signup_requests(id) ON DELETE CASCADE;


--
-- Name: gamified_personas gamified_personas_user_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".gamified_personas
    ADD CONSTRAINT gamified_personas_user_id_fkey FOREIGN KEY (user_id) REFERENCES "ZENK".signup_requests(id) ON DELETE CASCADE;


--
-- Name: kyc_documents kyc_documents_signup_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".kyc_documents
    ADD CONSTRAINT kyc_documents_signup_id_fkey FOREIGN KEY (signup_id) REFERENCES "ZENK".signup_requests(id) ON DELETE CASCADE;


--
-- Name: parental_consent_log parental_consent_log_student_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".parental_consent_log
    ADD CONSTRAINT parental_consent_log_student_id_fkey FOREIGN KEY (student_id) REFERENCES "ZENK".signup_requests(id) ON DELETE CASCADE;


--
-- Name: parental_consent_log parental_consent_log_verified_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".parental_consent_log
    ADD CONSTRAINT parental_consent_log_verified_by_admin_id_fkey FOREIGN KEY (verified_by_admin_id) REFERENCES "ZENK".signup_requests(id);


--
-- Name: sos_reports sos_reports_message_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".sos_reports
    ADD CONSTRAINT sos_reports_message_id_fkey FOREIGN KEY (message_id) REFERENCES "ZENK".chat_messages(id) ON DELETE CASCADE;


--
-- Name: sos_reports sos_reports_reporter_persona_id_fkey; Type: FK CONSTRAINT; Schema: ZENK; Owner: neondb_owner
--

ALTER TABLE ONLY "ZENK".sos_reports
    ADD CONSTRAINT sos_reports_reporter_persona_id_fkey FOREIGN KEY (reporter_persona_id) REFERENCES "ZENK".gamified_personas(id) ON DELETE CASCADE;


--
-- Name: account account_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.account
    ADD CONSTRAINT "account_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: invitation invitation_inviterId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT "invitation_inviterId_fkey" FOREIGN KEY ("inviterId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: invitation invitation_organizationId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT "invitation_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES neon_auth.organization(id) ON DELETE CASCADE;


--
-- Name: member member_organizationId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT "member_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES neon_auth.organization(id) ON DELETE CASCADE;


--
-- Name: member member_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT "member_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: session session_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT "session_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict qyChl5smWfuyHAfbUvjGhsfyX0WE5lNN5yNA3C7ZGNwY4AlVcjBNoloxg1vp0eZ

